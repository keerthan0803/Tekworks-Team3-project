# Artifact Inventory
Relevant source files
- [backend/models/churn_model_ada.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl)
- [backend/models/customer_segmentation_kmeans.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_kmeans.pkl)
- [backend/models/market_response_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_model.pkl)
- [backend/models/product_demand_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_demand_model.pkl)
- [backend/models/product_sensitivity_dt_model.joblib](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_dt_model.joblib)
- [backend/models/purchase_propensity_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_model.pkl)
- [backend/models/subscription_renewal_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/subscription_renewal_model.pkl)

The Tekworks Team3 ML platform relies on 15 serialized artifacts to serve predictions across seven distinct domains. These artifacts include trained machine learning models, feature scalers, and categorical encoders. All artifacts are stored in the `backend/models/` directory and are loaded into memory by the FastAPI service modules at startup.

## Artifact Summary Table

The following table details every artifact in the repository, its underlying algorithm, and the training script responsible for its generation.

| File Name | Associated Model | Algorithm | Format | Training Script |
| --- | --- | --- | --- | --- |
| `churn_model_ada.pkl` | Churn Prediction | AdaBoostClassifier | Pickle | `churn.py` |
| `subscription_renewal_model.pkl` | Subscription Renewal | Logistic Regression | Pickle | `subscription.py` |
| `market_response_model.pkl` | Market Response | Logistic Regression | Pickle | `market_responce.py` |
| `market_response_scaler.pkl` | Market Response | StandardScaler | Pickle | `market_responce.py` |
| `market_response_encoders.pkl` | Market Response | Dict (Encoders) | Pickle | `market_responce.py` |
| `product_demand_model.pkl` | Demand Forecasting | RandomForestRegressor | Pickle | `product_demand.py` |
| `product_demand_scaler.pkl` | Demand Forecasting | StandardScaler | Pickle | `product_demand.py` |
| `product_sensitivity_dt_model.joblib` | Product Sensitivity | DecisionTreeRegressor | Joblib | `product_sensitivity_analysis.py` |
| `product_sensitivity_label_encoders.joblib` | Product Sensitivity | LabelEncoder | Joblib | `product_sensitivity_analysis.py` |
| `purchase_propensity_model.pkl` | Purchase Propensity | Logistic Regression | Pickle | `purchase_propensity.py` |
| `purchase_propensity_scaler.pkl` | Purchase Propensity | StandardScaler | Pickle | `purchase_propensity.py` |
| `purchase_propensity_encoders.pkl` | Purchase Propensity | Dict (Encoders) | Pickle | `purchase_propensity.py` |
| `customer_segmentation_kmeans.pkl` | Segmentation | KMeans (k=4) | Pickle | `customer_segmentation.py` |
| `customer_segmentation_scaler.pkl` | Segmentation | StandardScaler | Pickle | `customer_segmentation.py` |
| `customer_segmentation_gender_encoder.pkl` | Segmentation | LabelEncoder | Pickle | `customer_segmentation.py` |

**Sources:**

- `backend/models/churn_model_ada.pkl`[1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-3)
- `backend/models/subscription_renewal_model.pkl`[1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-3)
- `backend/models/product_demand_model.pkl`[1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-3)
- `backend/models/product_sensitivity_dt_model.joblib`[1-5](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-5)

## The Three-Artifact Pattern

Most models in this system follow a "Three-Artifact Pattern." This ensures that the preprocessing steps applied during training are perfectly replicated during real-time inference.

1. **The Model (`*_model.pkl`):** The serialized weights and structure of the trained estimator (e.g., `LogisticRegression` or `KMeans`).
2. **The Scaler (`*_scaler.pkl`):** A fitted `StandardScaler` used to normalize numerical inputs. This prevents features with large magnitudes from dominating the model logic.
3. **The Encoders (`*_encoders.pkl`):** Either a dictionary of mappings or `LabelEncoder` objects used to transform categorical strings (e.g., "Male", "Yes") into numerical formats.

### Data Flow: Training to Artifacts

The diagram below illustrates how the training scripts process data and output the standardized artifact set.

**Model Training & Serialization Flow**

```mermaid
flowchart LR
    subgraph subGraph2 ["Code Entity Space: backend/models/"]
        F["purchase_propensity_encoders.pkl"]
        G["purchase_propensity_scaler.pkl"]
        H["purchase_propensity_model.pkl"]
    end
    subgraph subGraph1 ["Training Logic"]
        C["Fit LabelEncoders"]
        D["Fit StandardScaler"]
        E["Fit Estimator (Model)"]
    end
    subgraph subGraph0 ["Data Preparation"]
        A["Processed CSV"]
        B["Training Script (e.g. purchase_propensity.py)"]
    end
    A --> B
    B --> C
    B --> D
    B --> E
    C --> F
    D --> G
    E --> H
```

**Sources:**

- `backend/models/purchase_propensity_model.pkl`[1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-3)
- `backend/models/product_sensitivity_dt_model.joblib`[1-2](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-2)

## Serialization Formats

The project utilizes two primary serialization libraries:

### 1. Pickle (`.pkl`)

The majority of artifacts use the standard Python `pickle` module. This is used for models with smaller footprints, such as Logistic Regression and KMeans.

- **Example:**`subscription_renewal_model.pkl` is only 936 bytes [backend/models/subscription_renewal_model.pkl3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/subscription_renewal_model.pkl#L3-L3)
- **Example:**`churn_model_ada.pkl` (AdaBoost) is approximately 55 KB [backend/models/churn_model_ada.pkl3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L3-L3)

### 2. Joblib (`.joblib`)

`Joblib` is used for the Product Sensitivity model. It is generally more efficient for objects that carry large numerical arrays, such as deep Decision Trees.

- **Example:**`product_sensitivity_dt_model.joblib` contains extensive `numpy` array structures for the tree nodes [backend/models/product_sensitivity_dt_model.joblib1-5](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_dt_model.joblib#L1-L5)

## Binary Management with Git LFS

Because ML artifacts are binary files that change frequently during retraining, the repository uses **Git Large File Storage (LFS)**. This prevents the `.git` folder from bloating and ensures efficient cloning.

The repository stores "pointer files" in the main branch, while the actual binary content is hosted on LFS servers.

**Natural Language Space to Code Entity Space: LFS Mapping**

```mermaid
flowchart LR
    subgraph subGraph2 ["Local Filesystem (Actual)"]
        ACTUAL["Actual Binary Content (Retrieved on git lfs pull)"]
    end
    subgraph subGraph1 ["Code Entity: LFS Metadata"]
        V["version: https://git-lfs.github.com/spec/v1"]
        OID["oid sha256: 24ceb14e..."]
        SZ["size: 55931"]
    end
    subgraph subGraph0 ["Git Repository (Pointer)"]
        P["churn_model_ada.pkl"]
    end
    P --> V
    P --> OID
    P --> SZ
    OID -.-> ACTUAL
```

**Sources:**

- `backend/models/churn_model_ada.pkl`[1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-3)
- `backend/models/product_demand_model.pkl`[1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-3)

## Loading & Fail-Fast Mechanism

The inference services in `backend/py_files/` are designed to load these artifacts at the module level. If an artifact is missing or corrupted, the system raises a `RuntimeError` immediately upon startup, preventing the API from serving invalid predictions.

For example, the `product_demand_model.pkl` is a significant artifact (approx. 145 MB) that is loaded into memory once and reused for all subsequent requests to the `/predict/product-demand` endpoint [backend/models/product_demand_model.pkl3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_demand_model.pkl#L3-L3)

**Sources:**

- `backend/models/product_demand_model.pkl`[1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-3)
- `backend/models/market_response_model.pkl`[1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/1-3)