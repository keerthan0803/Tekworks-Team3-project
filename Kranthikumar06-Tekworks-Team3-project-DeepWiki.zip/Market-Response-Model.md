# Market Response Model
Relevant source files
- [.gitignore](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitignore)
- [backend/ipynb files/market_responce.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/market_responce.ipynb)
- [backend/models/market_response_encoders.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_encoders.pkl)
- [backend/models/market_response_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_model.pkl)
- [backend/models/market_response_scaler.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_scaler.pkl)
- [backend/py_files/market_responce.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py)
- [backend/py_files/market_response_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py)
- [backend/raw_datasets/campaign_responses.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/campaign_responses.csv)

The Market Response Model is a binary classification pipeline designed to predict whether a customer will respond to a marketing campaign based on demographic and financial attributes. It utilizes a Logistic Regression architecture to process input features such as income, credit score, and employment status.

### Data Flow Overview

The pipeline transitions from raw CSV data through a training script that generates three distinct serialized artifacts, which are then consumed by a FastAPI service for real-time inference.

**Data Flow Diagram**

```mermaid
flowchart LR
    subgraph subGraph2 ["Inference Service"]
        F["market_response_service.py"]
        G["MarketResponseRequest"]
        H["Prediction Result"]
    end
    subgraph subGraph1 ["Artifact Generation"]
        C["market_response_model.pkl"]
        D["market_response_scaler.pkl"]
        E["market_response_encoders.pkl"]
    end
    subgraph subGraph0 ["Data Preparation"]
        A["campaign_responses.csv"]
        B["market_responce.py"]
    end
    A --> B
    B --> C
    B --> D
    B --> E
    C --> F
    D --> F
    E --> F
    G --> F
    F --> H
```

Sources: [backend/py_files/market_responce.py11-16](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L11-L16)[backend/py_files/market_response_service.py14-22](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L14-L22)

---

## 1. Dataset and Training Pipeline

The model is trained on the `campaign_responses.csv` dataset. The training logic is encapsulated in `backend/py_files/market_responce.py`.

### Preprocessing Steps

1. **Feature Selection**: The `customer_id` column is dropped as it lacks predictive value [backend/py_files/market_responce.py19-20](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L19-L20)
2. **Categorical Encoding**: Three features (`gender`, `employed`, `marital_status`) are processed using `sklearn.preprocessing.LabelEncoder`[backend/py_files/market_responce.py22-28](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L22-L28)
3. **Target Mapping**: The target variable `responded` is converted from string labels ("Yes"/"No") to binary integers (1/0) [backend/py_files/market_responce.py30-33](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L30-L33)
4. **Scaling**: Features are normalized using `StandardScaler` to ensure the `LogisticRegression` model converges efficiently [backend/py_files/market_responce.py51-52](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L51-L52)

### Training Configuration

The model uses an 80/20 train-test split with a fixed `random_state=42` for reproducibility [backend/py_files/market_responce.py47-49](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L47-L49)

| Feature | Type | Source Column |
| --- | --- | --- |
| `age` | Numerical | `age` |
| `annual_income` | Numerical | `annual_income` |
| `credit_score` | Numerical | `credit_score` |
| `no_of_children` | Numerical | `no_of_children` |
| `gender` | Categorical | `gender` |
| `employed` | Categorical | `employed` |
| `marital_status` | Categorical | `marital_status` |

Sources: [backend/py_files/market_responce.py35-45](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L35-L45)[backend/raw_datasets/campaign_responses.csv1-6](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/campaign_responses.csv#L1-L6)

---

## 2. Serialized Artifacts

The training script outputs three artifacts using `joblib` to the `backend/models/` directory. These are tracked via Git LFS [backend/models/market_response_model.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_model.pkl#L1-L3)

1. **`market_response_model.pkl`**: The trained `LogisticRegression` estimator [backend/py_files/market_responce.py57](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L57-L57)
2. **`market_response_scaler.pkl`**: The `StandardScaler` instance containing the mean and variance of the training set [backend/py_files/market_responce.py58](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L58-L58)
3. **`market_response_encoders.pkl`**: A dictionary mapping column names to their respective `LabelEncoder` instances [backend/py_files/market_responce.py59](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L59-L59)

Sources: [backend/py_files/market_responce.py57-59](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_responce.py#L57-L59)[backend/py_files/market_response_service.py10-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L10-L12)

---

## 3. Inference Service Implementation

The inference logic is handled by `market_response_service.py`. It implements a "fail-fast" mechanism that raises a `RuntimeError` if model artifacts are missing at module load time [backend/py_files/market_response_service.py14-22](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L14-L22)

### Request Schema

The service uses a flat Pydantic model `MarketResponseRequest`. Unlike other services in the codebase, it does not wrap its fields in a nested `data` object [backend/py_files/market_response_service.py25-32](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L25-L32)

### Encoding Helper

The `encode_market_value` function handles the transformation of categorical strings into the integers expected by the model. It uses the serialized `market_encoders`[backend/py_files/market_response_service.py35-47](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L35-L47)

**Inference Logic Diagram**

```mermaid
sequenceDiagram
    participant API as "app.py /predict/market-response"
    participant SVC as "market_response_service.py"
    participant ENC as "market_encoders (LabelEncoder)"
    participant SCL as "market_scaler (StandardScaler)"
    participant MDL as "market_model (LogisticRegression)"
    API->>SVC: predict_market_response(MarketResponseRequest)
    SVC->>ENC: encode_market_value("gender", val)
    SVC->>ENC: encode_market_value("employed", val)
    SVC->>ENC: encode_market_value("marital_status", val)
    SVC->>SCL: transform(features)
    SCL-->>SVC: scaled_features
    SVC->>MDL: predict(scaled_features)
    MDL-->>SVC: [1] or [0]
    SVC-->>API: {"prediction": "Responded", "prediction_numeric": 1}
```

### Prediction Logic

The `predict_market_response` function performs the following operations:

1. Constructs a 2D NumPy array from the request attributes [backend/py_files/market_response_service.py51-63](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L51-L63)
2. Calls `encode_market_value` for all categorical fields [backend/py_files/market_response_service.py58-60](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L58-L60)
3. Applies the `market_scaler` transformation [backend/py_files/market_response_service.py65](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L65-L65)
4. Executes the model prediction and returns a dictionary containing both a string label ("Responded" vs "Not Responded") and the raw numeric result [backend/py_files/market_response_service.py66-68](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L66-L68)

Sources: [backend/py_files/market_response_service.py50-68](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L50-L68)