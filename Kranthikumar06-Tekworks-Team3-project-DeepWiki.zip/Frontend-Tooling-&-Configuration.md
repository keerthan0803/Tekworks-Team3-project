# Frontend Tooling & Configuration
Relevant source files
- [frontend/eslint.config.js](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/eslint.config.js)
- [frontend/package-lock.json](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package-lock.json)
- [frontend/package.json](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json)
- [frontend/tsconfig.app.json](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.app.json)
- [frontend/tsconfig.json](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.json)
- [frontend/tsconfig.node.json](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.node.json)
- [frontend/vite.config.ts](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/vite.config.ts)

This section details the build toolchain and development environment configuration for the Intellix Premium frontend. The project utilizes a modern ESM-based stack centered around Vite, TypeScript, and ESLint to ensure rapid development cycles and type safety across the ML workspace UI.

## Build Toolchain (Vite)

The application uses **Vite** as the primary build tool and development server. Vite leverages native ES modules in the browser to provide near-instant hot module replacement (HMR).

### Vite Configuration

The configuration is defined in `frontend/vite.config.ts`. It utilizes the `@vitejs/plugin-react` to enable React-specific features such as Fast Refresh [frontend/vite.config.ts1-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/vite.config.ts#L1-L7)

| Feature | Implementation |
| --- | --- |
| **Plugin** | `@vitejs/plugin-react` |
| **Module Type** | `module` (defined in `package.json`) |
| **Base Config** | `defineConfig` utility |

**Diagram: Vite Build and Dev Flow**

```mermaid
flowchart LR
    I["vite.config.ts"]
    subgraph Production
        E["vite build (Command)"]
        F["Rollup Bundler"]
        G["dist/ assets"]
        H["Tree Shaking & Minification"]
    end
    subgraph Development
        A["vite (Command)"]
        B["Vite Dev Server"]
        C["HMR (Hot Module Replacement)"]
        D["ESBuild Pre-bundling"]
    end
    A --> B
    B --> C
    B --> D
    E --> F
    F --> G
    F --> H
    I -.-> B
    I -.-> F
```

Sources: [frontend/vite.config.ts1-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/vite.config.ts#L1-L7)[frontend/package.json5-10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L5-L10)

## TypeScript Configuration

The project employs a modular TypeScript configuration using "Project References" to separate the application logic from the build tool configuration.

### Configuration Hierarchy

- **`tsconfig.json`**: The root configuration that orchestrates the sub-configs via the `references` array [frontend/tsconfig.json1-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.json#L1-L7)
- **`tsconfig.app.json`**: Governs the source code in `src/`. It targets `es2023`, uses `react-jsx` for the transform, and includes `vite/client` types for environment variables and asset imports [frontend/tsconfig.app.json1-25](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.app.json#L1-L25)
- **`tsconfig.node.json`**: Specifically handles the configuration for `vite.config.ts`, including `node` types [frontend/tsconfig.node.json1-24](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.node.json#L1-L24)

### Key Compiler Options

| Option | Value | Purpose |
| --- | --- | --- |
| `target` | `es2023` | Modern JavaScript output [frontend/tsconfig.app.json4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.app.json#L4-L4) |
| `moduleResolution` | `bundler` | Optimized for modern bundlers like Vite [frontend/tsconfig.app.json11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.app.json#L11-L11) |
| `jsx` | `react-jsx` | Enables automatic JSX transform [frontend/tsconfig.app.json16](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.app.json#L16-L16) |
| `noEmit` | `true` | Vite handles transpilation; TS is used for type checking only [frontend/tsconfig.app.json15](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.app.json#L15-L15) |

Sources: [frontend/tsconfig.json1-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.json#L1-L7)[frontend/tsconfig.app.json1-25](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.app.json#L1-L25)[frontend/tsconfig.node.json1-24](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/tsconfig.node.json#L1-L24)

## Linting & Code Quality (ESLint)

The project uses ESLint with the flat configuration format (`eslint.config.js`) to enforce code quality and React best practices.

### Plugin Integration

The configuration integrates several specialized plugins:

- **`typescript-eslint`**: Provides rules for TypeScript-specific patterns [frontend/eslint.config.js5](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/eslint.config.js#L5-L5)
- **`eslint-plugin-react-hooks`**: Enforces the Rules of Hooks [frontend/eslint.config.js3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/eslint.config.js#L3-L3)
- **`eslint-plugin-react-refresh`**: Validates that components are compatible with Fast Refresh [frontend/eslint.config.js4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/eslint.config.js#L4-L4)

### Configuration Logic

The setup ignores the `dist` directory and applies strict linting to all `.ts` and `.tsx` files using a combination of recommended presets [frontend/eslint.config.js8-22](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/eslint.config.js#L8-L22)

**Diagram: Linting Architecture**

```mermaid
flowchart LR
    subgraph subGraph2 ["Target Entities"]
        APP["frontend/src/**/*.tsx"]
        CFG_FILES["vite.config.ts"]
    end
    subgraph subGraph1 ["Presets & Plugins"]
        JS["@eslint/js"]
        TS["typescript-eslint"]
        RH["eslint-plugin-react-hooks"]
        RR["eslint-plugin-react-refresh"]
    end
    subgraph subGraph0 ["ESLint Engine"]
        E_CFG["eslint.config.js"]
    end
    E_CFG --> JS
    E_CFG --> TS
    E_CFG --> RH
    E_CFG --> RR
    APP --> E_CFG
    CFG_FILES --> E_CFG
```

Sources: [frontend/eslint.config.js1-22](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/eslint.config.js#L1-L22)[frontend/package.json20-27](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L20-L27)

## Package Scripts

The `package.json` file defines the standard lifecycle scripts for development, building, and maintenance.

| Script | Command | Description |
| --- | --- | --- |
| `dev` | `vite` | Starts the development server [frontend/package.json7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L7-L7) |
| `build` | `tsc -b && vite build` | Runs type checking across all projects (`-b`) before bundling [frontend/package.json8](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L8-L8) |
| `lint` | `eslint .` | Executes the ESLint suite across the project [frontend/package.json9](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L9-L9) |
| `preview` | `vite preview` | Serves the production build locally for verification [frontend/package.json10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L10-L10) |

### Dependencies Overview

The project maintains a lean dependency profile, relying on **React 19** for the UI and a comprehensive set of devDependencies for the build pipeline [frontend/package.json12-29](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L12-L29)

**Diagram: Script Dependency Flow**

```mermaid
flowchart LR
    subgraph subGraph1 ["Underlying Tools"]
        VITE["vite"]
        TSC["tsc -b"]
        ESL["eslint"]
    end
    subgraph subGraph0 ["package.json scripts"]
        DEV["npm run dev"]
        BUILD["npm run build"]
        LINT["npm run lint"]
    end
    DEV --> VITE
    BUILD --> TSC
    TSC --> VITE
    LINT --> ESL
```

Sources: [frontend/package.json6-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L6-L11)[frontend/package-lock.json7-28](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package-lock.json#L7-L28)