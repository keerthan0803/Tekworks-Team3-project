# Backend Architecture
Relevant source files
- [backend/app.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py)
- [backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv)
- [backend/raw_datasets/Telco_customer_churn.xlsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Telco_customer_churn.xlsx)
- [backend/raw_datasets/subscription_dataset.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/subscription_dataset.csv)
- [backend/requirements.txt](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt)

The backend of the Tekworks Team3 project is a high-performance **FastAPI** application designed to serve seven distinct machine learning models. It operates on a "hub-and-spoke" dependency model where a central application script manages routing and CORS, while specialized service modules handle the heavy lifting of data preprocessing and model inference.

## Application Hub (`app.py`)

The file `backend/app.py` serves as the entry point and central orchestrator for the entire backend service [backend/app.py7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L7-L7) It initializes the FastAPI instance and defines the high-level REST interface.

### Dynamic Service Loading

To maintain a clean project structure while allowing the central hub to access inference logic, the backend utilizes dynamic `sys.path` manipulation. The `py_files` directory, which contains all model-specific logic, is added to the Python search path at runtime [backend/app.py17-18](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L17-L18) This allows `app.py` to import specialized service functions and Pydantic schemas as if they were top-level packages [backend/app.py20-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L20-L44)

### CORS Configuration

To facilitate communication with the Vite-based frontend, the application implements a permissive Cross-Origin Resource Sharing (CORS) policy.

- **Allowed Origins:** All (`*`) [backend/app.py11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L11-L11)
- **Allowed Methods:** All (`*`) [backend/app.py13](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L13-L13)
- **Allowed Headers:** All (`*`) [backend/app.py14](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L14-L14)

For a deep dive into the specific API routes and request/response validation, see **[FastAPI Application & REST Endpoints](/Kranthikumar06/Tekworks-Team3-project/2.1-fastapi-application-and-rest-endpoints)**.

## Hub-and-Spoke Architecture

The backend follows a strict separation of concerns between the API layer and the Inference layer.

| Component | Role | Code Entity |
| --- | --- | --- |
| **The Hub** | Routing, Middleware, and Path Management | `app.py` |
| **The Spokes** | Preprocessing, Artifact Loading, and Inference | `py_files/*_service.py` |
| **The Artifacts** | Serialized ML Models and Scalers | `models/*.pkl`, `models/*.joblib` |

### System Connectivity Diagram

This diagram illustrates how the central hub connects to the individual service "spokes" and their respective data artifacts.

**Backend Service Mapping**

```mermaid
flowchart LR
    subgraph subGraph2 ["Model Artifacts (models/)"]
        CH_PKL["churn_model_ada.pkl"]
        SUB_PKL["subscription_renewal_model.pkl"]
        SENS_JOB["product_sensitivity_dt_model.joblib"]
    end
    subgraph subGraph1 ["Inference Spokes (py_files/)"]
        CS["churn_service.py"]
        SS["subscription_service.py"]
        PS["product_sensitivity_service.py"]
    end
    subgraph subGraph0 ["The Hub (app.py)"]
        API["FastAPI Instance"]
        CORS["CORSMiddleware"]
    end
    API --> CS
    API --> SS
    API --> PS
    CS --> CH_PKL
    SS --> SUB_PKL
    PS --> SENS_JOB
```

Sources: [backend/app.py7-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L7-L44)[backend/requirements.txt3-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L3-L7)

## Inference Service Pattern

Every predictive model in the system is wrapped in a standardized "Service" module located in `backend/py_files/`. This pattern ensures that `app.py` can interact with every model using a consistent interface.

1. **Artifact Loading:** Services load their respective `.pkl` or `.joblib` files at the module level to ensure fast response times during inference.
2. **Schema Definition:** Each service defines a `PredictRequest` class (using Pydantic) to validate incoming JSON payloads.
3. **Data Preparation:** A `prepare_input` function converts raw JSON/Dictionary data into a `pandas.DataFrame`, applying necessary scaling or encoding.
4. **Prediction:** A `predict_*` function executes the model's `predict` or `predict_proba` method and returns a serializable dictionary.

For details on the internal logic of these modules, see **[Inference Service Pattern](/Kranthikumar06/Tekworks-Team3-project/2.2-inference-service-pattern)**.

## Data Entity Mapping

The following diagram bridges the gap between the high-level predictive features and the specific code entities that handle them.

**Feature to Code Mapping**

```mermaid
flowchart TD
    subgraph subGraph1 ["Code Entities (backend/)"]
        REQ["PredictRequest (Pydantic Model)"]
        PREP["prepare_input (Function)"]
        MOD["model.predict (Method)"]
    end
    subgraph subGraph0 ["Natural Language Features"]
        F1["Customer Age/Income"]
        F2["Subscription Type"]
        F3["Monthly Usage"]
    end
    F1 --> REQ
    F2 --> REQ
    F3 --> REQ
    REQ --> PREP
    PREP --> MOD
```

Sources: [backend/app.py20-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L20-L44)[backend/requirements.txt1-6](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L6)

## Backend Dependencies

The environment is powered by a standard ML stack, defined in `backend/requirements.txt`. Key dependencies include:

- **Web Framework:**`fastapi` and `uvicorn`[backend/requirements.txt3-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L3-L11)
- **Data Processing:**`pandas`, `numpy`, and `scipy`[backend/requirements.txt1-8](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L8)
- **Machine Learning:**`scikit-learn` and `joblib`[backend/requirements.txt6-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L6-L7)
- **Data Formats:**`openpyxl` (for Excel-based raw datasets) [backend/requirements.txt9](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L9-L9)

Sources: [backend/requirements.txt1-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L11)