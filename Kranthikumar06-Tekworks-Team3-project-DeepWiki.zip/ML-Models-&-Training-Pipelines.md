# ML Models & Training Pipelines
Relevant source files
- [README.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1)
- [backend/models/churn_model_ada.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl)
- [backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv)
- [backend/raw_datasets/Telco_customer_churn.xlsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Telco_customer_churn.xlsx)
- [backend/raw_datasets/subscription_dataset.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/subscription_dataset.csv)
- [backend/requirements.txt](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt)
- [document.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1)

This page provides a technical overview of the seven machine learning models integrated into the Tekworks system. It describes the common two-stage lifecycle, the directory structure for data and artifacts, and the training pipelines used to generate the predictive services.

## Lifecycle Overview

The system follows a decoupled architecture where model development and production inference are separated into two distinct phases.

1. **Offline Training Phase**: Data scientists use Jupyter notebooks in `backend/ipynb files/` for Exploratory Data Analysis (EDA) and preprocessing. Python scripts in `backend/py_files/` then execute the final training pipelines, consuming data from `backend/raw_datasets/` or `backend/processed_datasets/` and persisting serialized artifacts to `backend/models/`.
2. **Online Inference Phase**: The FastAPI backend loads these artifacts at runtime. When a request hits a `/predict/*` endpoint, the corresponding service module in `backend/py_files/` performs real-time preprocessing and generates a prediction.

### Directory Conventions

| Directory | Purpose |
| --- | --- |
| `backend/raw_datasets/` | Original source files (CSV, XLSX) used for initial training. |
| `backend/processed_datasets/` | Cleaned and feature-engineered datasets produced by notebooks. |
| `backend/models/` | Serialized model objects (`.pkl`, `.joblib`) and scalers. |
| `backend/py_files/` | Training scripts (e.g., `churn.py`) and inference services (e.g., `churn_service.py`). |

Sources: [README.md36-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L36-L44)[document.md22-35](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L22-L35)

## Training & Inference Architecture

The following diagram illustrates how raw data flows through the training scripts to become serialized artifacts, which are then utilized by the API service layer.

### ML Data Flow Diagram

```mermaid
flowchart TD
    subgraph subGraph3 ["Inference Space (Code Entities)"]
        SVC["py_files/*_service.py"]
        API["app.py (FastAPI)"]
    end
    subgraph subGraph2 ["Artifact Space"]
        MODELS["models/*.pkl / *.joblib"]
    end
    subgraph subGraph1 ["Training Space (Code Entities)"]
        TS["py_files/*.py (Training Scripts)"]
        NB["ipynb_files/*.ipynb"]
    end
    subgraph subGraph0 ["Data Space"]
        RAW["raw_datasets/"]
        PROC["processed_datasets/"]
    end
    RAW --> NB
    NB --> PROC
    PROC --> TS
    TS --> MODELS
    MODELS -->|"Loaded by"| SVC
    API -->|"Calls"| SVC
```

Sources: [README.md36-55](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L36-L55)[document.md22-30](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L22-L30)

## Model Domains

The platform serves seven distinct predictive models. Each model has a dedicated training script and a corresponding inference service.

### 1. Churn Prediction

Predicts the likelihood of a customer leaving the service. It uses an `AdaBoostClassifier` trained on telco customer data.

- **Key Files**: `churn.py` (Training), `churn_service.py` (Inference).
- **Artifact**: `churn_model_ada.pkl`.
- **Details**: See [Churn Prediction Model](/Kranthikumar06/Tekworks-Team3-project/3.1-churn-prediction-model).

### 2. Subscription Renewal

Predicts if a customer will renew their current subscription. Utilizes `LogisticRegression` with features like tenure and contract type.

- **Key Files**: `subscription.py` (Training), `subscription_service.py` (Inference).
- **Artifact**: `subscription_renewal_model.pkl`.
- **Details**: See [Subscription Renewal Model](/Kranthikumar06/Tekworks-Team3-project/3.2-subscription-renewal-model).

### 3. Market Response

Determines the probability of a customer responding to a marketing campaign based on demographics and credit score.

- **Key Files**: `market_responce.py` (Training), `market_response_service.py` (Inference).
- **Artifacts**: `market_response_model.pkl`, `market_response_scaler.pkl`.
- **Details**: See [Market Response Model](/Kranthikumar06/Tekworks-Team3-project/3.3-market-response-model).

### 4. Product Demand Forecasting

Forecasts future product demand using a `RandomForestRegressor`. It processes time-series data by excluding date columns during the regression fit.

- **Key Files**: `product_demand.py` (Training), `product_demand_service.py` (Inference).
- **Artifact**: `product_demand_model.pkl`.
- **Details**: See [Product Demand Forecasting Model](/Kranthikumar06/Tekworks-Team3-project/3.4-product-demand-forecasting-model).

### 5. Product Sensitivity (Dynamic Pricing)

Analyzes price sensitivity to predict historical ride costs, facilitating dynamic pricing strategies via a `DecisionTreeRegressor`.

- **Key Files**: `product_sensitivity_analysis.py` (Training), `product_sensitivity_service.py` (Inference).
- **Artifact**: `product_sensitivity_dt_model.joblib`.
- **Details**: See [Product Sensitivity (Dynamic Pricing) Model](/Kranthikumar06/Tekworks-Team3-project/3.5-product-sensitivity-(dynamic-pricing)-model).

### 6. Purchase Propensity

Calculates the probability that a user will make a purchase based on attributes like age, income, and city.

- **Key Files**: `purchase_propensity.py` (Training), `purchase_propensity_service.py` (Inference).
- **Artifact**: `purchase_propensity_model.pkl`.
- **Details**: See [Purchase Propensity Model](/Kranthikumar06/Tekworks-Team3-project/3.6-purchase-propensity-model).

### 7. Customer Segmentation

Groups customers into four segments (At-Risk, Occasional, Regular, High-Value) using `KMeans` clustering and `t-SNE` for 2D visualization.

- **Key Files**: `customer_segmentation.py` (Training), `customer_segmentation_service.py` (Inference).
- **Artifact**: `kmeans_model.pkl`.
- **Details**: See [Customer Segmentation Model](/Kranthikumar06/Tekworks-Team3-project/3.7-customer-segmentation-model).

Sources: [README.md6-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L6-L12)[document.md42-63](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L42-L63)

## Model-to-Code Mapping

This diagram bridges the conceptual models to their specific implementation files and artifacts within the repository.

### Entity Relationship Diagram

```mermaid
classDiagram
    class FastAPI_App {
        app.py
        POST /predict/churn
        POST /predict/segmentation
    }
    class Churn_Logic {
        churn.py
        churn_service.py
        churn_model_ada.pkl
    }
    class Segmentation_Logic {
        customer_segmentation.py
        customer_segmentation_service.py
        kmeans_model.pkl
    }
    class Demand_Logic {
        product_demand.py
        product_demand_service.py
        product_demand_model.pkl
    }
    FastAPI_App --> Churn_Logic : "imports & calls"
    FastAPI_App --> Segmentation_Logic : "imports & calls"
    FastAPI_App --> Demand_Logic : "imports & calls"
```

Sources: [README.md38-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L38-L44)[document.md42-63](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L42-L63)

## Technical Requirements

All models rely on the following core stack for training and serialization:

- **Scikit-learn**: Primary library for all classifiers and regressors [backend/requirements.txt6](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L6-L6)
- **Joblib / Pickle**: Used for model serialization and persistence [backend/requirements.txt7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L7-L7)
- **Pandas/NumPy**: Used for data manipulation during the `prepare_input` stage [backend/requirements.txt1-2](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L2)

Sources: [backend/requirements.txt1-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L11)