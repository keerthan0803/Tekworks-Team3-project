# Purchase Propensity Model
Relevant source files
- [backend/ipynb files/Purchase_Propensity_Modeling.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Purchase_Propensity_Modeling.ipynb)
- [backend/models/purchase_propensity_encoders.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_encoders.pkl)
- [backend/models/purchase_propensity_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_model.pkl)
- [backend/models/purchase_propensity_scaler.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_scaler.pkl)
- [backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv)
- [backend/py_files/purchase_propensity.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py)
- [backend/py_files/purchase_propensity_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py)

The Purchase Propensity Model is a predictive pipeline designed to estimate the likelihood of a customer making a purchase based on demographic and behavioral attributes. It utilizes a Logistic Regression classifier to provide both binary classifications ("Purchased" vs "Not Purchased") and continuous probability scores.

## Data Pipeline and Training

The model lifecycle begins with raw customer data and proceeds through an offline training script that serializes the necessary components for online inference.

### Dataset Overview

The model is trained on the `Customer_Attributes_and_Purchase_Propensity.csv` dataset [backend/ipynb files/Purchase_Propensity_Modeling.ipynb116-117](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Purchase_Propensity_Modeling.ipynb#L116-L117) A processed version is maintained for training consistency [backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv1-10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv#L1-L10)

Key features include:

- **Demographics**: `Age`, `City`, `Marital_Status`.
- **Financials**: `Income`.
- **Behavioral**: `Score` (a normalized metric representing customer engagement).
- **Target**: `Purchased` (Binary: 0 or 1).

### Training Implementation

The training logic is encapsulated in `purchase_propensity.py`. The script performs the following steps:

1. **Categorical Encoding**: Uses `LabelEncoder` for `City` and `Marital_Status`[backend/py_files/purchase_propensity.py30-36](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py#L30-L36)
2. **Feature Scaling**: Applies `StandardScaler` to all features to ensure the Logistic Regression coefficients are properly regularized [backend/py_files/purchase_propensity.py45-47](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py#L45-L47)
3. **Model Fitting**: Trains a `LogisticRegression` model with a maximum of 1000 iterations [backend/py_files/purchase_propensity.py49-50](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py#L49-L50)
4. **Artifact Serialization**: Saves three distinct `.pkl` files using `joblib` to ensure the inference service can recreate the exact training environment [backend/py_files/purchase_propensity.py52-54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py#L52-L54)

**Sources:**

- [backend/py_files/purchase_propensity.py12-57](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py#L12-L57)
- [backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv1-21](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv#L1-L21)
- [backend/ipynb files/Purchase_Propensity_Modeling.ipynb154-160](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Purchase_Propensity_Modeling.ipynb#L154-L160)

---

## Technical Architecture

The following diagram illustrates the flow from the raw data to the serialized artifacts used by the API.

**Purchase Propensity Training Flow**

```mermaid
flowchart TD
    subgraph subGraph2 ["Models Directory"]
        M_PKL["purchase_propensity_model.pkl"]
        S_PKL["purchase_propensity_scaler.pkl"]
        E_PKL["purchase_propensity_encoders.pkl"]
    end
    subgraph subGraph1 ["Training Script: purchase_propensity.py"]
        LOAD["pd.read_csv()"]
        ENC["LabelEncoder (City, Marital_Status)"]
        SCALE["StandardScaler"]
        TRAIN["LogisticRegression.fit()"]
    end
    subgraph subGraph0 ["Data Layer"]
        RAW["Customer_Attributes_and_Purchase_Propensity.csv"]
        PROC["Customer_Attributes_and_Purchase_Propensity_processed.csv"]
    end
    RAW --> PROC
    PROC --> LOAD
    LOAD --> ENC
    ENC --> SCALE
    SCALE --> TRAIN
    TRAIN --> M_PKL
    SCALE --> S_PKL
    ENC --> E_PKL
```

**Sources:**

- [backend/py_files/purchase_propensity.py13-22](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py#L13-L22)
- [backend/py_files/purchase_propensity.py52-54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py#L52-L54)

---

## Inference Service

The `purchase_propensity_service.py` module handles real-time prediction requests. It loads artifacts at module startup and provides a `predict_purchase_propensity` function.

### Artifact Loading

The service uses a "fail-fast" approach, raising a `RuntimeError` if the serialized models are missing [backend/py_files/purchase_propensity_service.py26-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L26-L34) It also loads the processed dataset to establish `expected_columns`, ensuring the input features match the training schema [backend/py_files/purchase_propensity_service.py36-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L36-L44)

### Inference Workflow

1. **Request Handling**: Receives a `PredictRequest` containing a data dictionary [backend/py_files/purchase_propensity_service.py11-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L11-L12)
2. **Preprocessing (`prepare_input`)**:

- Converts the dictionary to a `pd.DataFrame`[backend/py_files/purchase_propensity_service.py48](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L48-L48)
- Applies saved `LabelEncoder` objects to categorical fields [backend/py_files/purchase_propensity_service.py50-54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L50-L54)
- Reindexes the dataframe to match `expected_columns`, filling missing values with 0 [backend/py_files/purchase_propensity_service.py61](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L61-L61)
3. **Scaling**: Transforms the data using `purchase_scaler`[backend/py_files/purchase_propensity_service.py69](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L69-L69)
4. **Prediction & Probability**:

- Calls `predict()` for the binary label [backend/py_files/purchase_propensity_service.py70](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L70-L70)
- Calls `predict_proba()` to extract the confidence score for the "Purchased" class (index 1) [backend/py_files/purchase_propensity_service.py94-97](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L94-L97)

**Inference Entity Mapping**

```mermaid
flowchart LR
    subgraph subGraph2 ["Output Space"]
        RES["JSON Response"]
        LABEL["'prediction': 'Purchased'"]
        CONF["'probability': 0.85"]
    end
    subgraph purchase_propensity_service_py ["purchase_propensity_service.py"]
        PREP["prepare_input()"]
        MODEL["purchase_model"]
        SCALER["purchase_scaler"]
        PROBA["predict_proba()"]
    end
    subgraph subGraph0 ["Input Space"]
        REQ["PredictRequest (JSON)"]
    end
    REQ --> PREP
    PREP --> SCALER
    SCALER --> MODEL
    MODEL --> PROBA
    PROBA --> RES
    RES --> LABEL
    RES --> CONF
```

**Sources:**

- [backend/py_files/purchase_propensity_service.py47-61](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L47-L61)
- [backend/py_files/purchase_propensity_service.py64-101](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L64-L101)

---

## Model Artifacts

The system relies on three specific artifacts stored in the `models/` directory. These are managed via Git LFS due to their binary nature.

| Artifact File | Role | Component |
| --- | --- | --- |
| `purchase_propensity_model.pkl` | Classification | `LogisticRegression`[backend/models/purchase_propensity_model.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_model.pkl#L1-L3) |
| `purchase_propensity_scaler.pkl` | Normalization | `StandardScaler`[backend/models/purchase_propensity_scaler.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_scaler.pkl#L1-L3) |
| `purchase_propensity_encoders.pkl` | Categorical Mapping | `Dict[str, LabelEncoder]`[backend/models/purchase_propensity_encoders.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_encoders.pkl#L1-L3) |

**Sources:**

- [backend/py_files/purchase_propensity_service.py16-18](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L16-L18)
- [backend/py_files/purchase_propensity.py20-22](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity.py#L20-L22)