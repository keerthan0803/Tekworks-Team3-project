# UI Design System & Styling
Relevant source files
- [frontend/index.html](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/index.html)
- [frontend/public/favicon.svg](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/public/favicon.svg)
- [frontend/public/icons.svg](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/public/icons.svg)
- [frontend/src/App.css](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css)
- [frontend/src/assets/hero.png](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/assets/hero.png)
- [frontend/src/index.css](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css)

The Intellix Premium UI is built on a standardized design system that emphasizes clarity, responsiveness, and a professional "workspace" aesthetic. The styling is implemented using CSS custom properties (tokens) for theme consistency and a component-based CSS architecture that supports both interactive model exploration and static report generation.

## Core Design Tokens & Global Styles

The system uses CSS variables defined in the `:root` of the global stylesheet to ensure consistent application of colors, typography, and spacing across the application.

### Color Palette & Typography

The palette focuses on a "Premium Blue" primary color with a neutral slate scale for text and borders.

| Category | Variable | Value | Role |
| --- | --- | --- | --- |
| **Primary** | `--primary` | `#0055D4` | Action buttons, active states, brand elements |
| **Background** | `--bg-main` | `#F3F6FA` | Main application background |
| **Background** | `--bg-card` | `#FFFFFF` | Form containers and output panes |
| **Text** | `--text-primary` | `#0F172A` | Headings and primary labels |
| **Text** | `--text-muted` | `#94A3B8` | Helper text and breadcrumbs |
| **Border** | `--border-light` | `#E2E8F0` | Subtle section separators |

The system defaults to the **Inter** typeface for sans-serif text and **JetBrains Mono** for technical data displays [frontend/src/index.css21-22](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L21-L22)

### Scrollbar Utilities

To maintain a high-end feel, custom scrollbars are defined for WebKit browsers, featuring a slim 6px profile and rounded thumbs [frontend/src/index.css75-91](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L75-L91) A `.no-scrollbar` utility is also provided for clean UI transitions [frontend/src/index.css94-100](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L94-L100)

**Sources:**

- [frontend/src/index.css1-30](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L1-L30)
- [frontend/src/index.css75-100](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L75-L100)
- [frontend/index.html8-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/index.html#L8-L11)

---

## Application Layout Architecture

The application follows a **Sidebar + Main Frame** layout pattern. The root container uses `display: flex` with a minimum height of `100vh`[frontend/src/App.css3-8](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L3-L8)

### Component Hierarchy Diagram

```mermaid
flowchart LR
    subgraph subGraph1 ["intellix-app-container #91;App.css#93;"]
        A["intellix-sidebar"]
        B["sidebar-brand-section"]
        C["sidebar-nav-container"]
        D["intellix-main-frame"]
        E["intellix-logo-header"]
        subgraph subGraph0 ["Workspace Content"]
            F["intellix-workspace-content"]
            G["content-header-row"]
            H["workspace-interactive-layout"]
            I["parameters-card"]
            J["parameters-body (Form)"]
            K["parameters-card-result-section (Output)"]
        end
    end
    A --> B
    A --> C
    D --> E
    D --> F
    F --> G
    F --> H
    H --> I
    I --> J
    I --> K
```

**Sources:**

- [frontend/src/App.css3-23](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L3-L23)
- [frontend/src/App.css117-124](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L117-L124)
- [frontend/src/App.css162-182](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L162-L182)

### Sidebar Implementation

The sidebar is a `sticky` element with a fixed width of `260px`[frontend/src/App.css11-23](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L11-L23) It includes:

- **Active State Indicators**: Uses a `.nav-active-bar` (a 3.5px vertical line) to highlight the current selection [frontend/src/App.css106-114](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L106-L114)
- **Navigation Buttons**: Styled with `transition: all 0.2s` for smooth hover effects [frontend/src/App.css64-88](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L64-L88)

---

## Key UI Components

### Parameters Form & Inputs

The `parameters-body` utilizes a grid or flex layout to organize input fields. Labels are styled with `font-weight: 600` and `text-transform: uppercase` for readability [frontend/src/App.css334-360](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L334-L360)

### Prediction Output Pane

When a prediction is returned from the backend, it is displayed in the `parameters-card-result-section`[frontend/src/App.css253-257](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L253-L257) This section contains:

- **Probability Meter**: A container that visualizes the confidence of the model [frontend/src/App.css564-570](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L564-L570)
- **Radar Scanner**: A decorative animation element used during the "loading" state to simulate data processing [frontend/src/App.css738-750](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L738-L750)

### Model Catalog

A specialized view for browsing available models, using a card-based grid layout [frontend/src/App.css1010-1030](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L1010-L1030)

```mermaid
classDiagram
    class ParametersCard {
        +options-header-bar
        +parameters-body
        +parameters-card-result-section
    }
    class PredictionOutput {
        +probability-meter-container
        +result-value-display
        +radar-scanner
    }
    class ToastSystem {
        +intellix-toast
        +toast-success
        +toast-error
    }
    ParametersCard --|> PredictionOutput : contains
```

**Sources:**

- [frontend/src/App.css242-257](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L242-L257)
- [frontend/src/App.css564-600](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L564-L600)
- [frontend/src/App.css915-950](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L915-L950)

---

## Responsive Design & Print Export

### Breakpoints

The UI adapts to different screen sizes using standard media queries:

- **Desktop/Large Screens**: Default sidebar + main frame.
- **Tablets/Small Laptops**: The `workspace-interactive-layout` manages the relationship between the input form and result pane [frontend/src/App.css234-239](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L234-L239)

### Print Optimization (@media print)

The application includes specific rules for the `handleExport` (Report Export) functionality. When `window.print()` is triggered:

1. **Sidebar Hidden**: The `.intellix-sidebar` is set to `display: none`[frontend/src/App.css1110-1115](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L1110-L1115)
2. **Layout Expansion**: The `.intellix-main-frame` and `.intellix-app-container` expand to fill the full width of the paper [frontend/src/App.css1118-1125](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L1118-L1125)
3. **Card Shadows**: Box shadows are removed from `.parameters-card` to ensure clean printing on physical media [frontend/src/App.css1130-1135](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L1130-L1135)

**Sources:**

- [frontend/src/App.css1108-1150](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L1108-L1150)
- [frontend/src/App.tsx212-214](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L212-L214) (handleExport call site)

---

## Asset Management

The design system integrates several asset types:

- **SVG Symbols**: Located in `public/icons.svg`, these are referenced throughout the app using the `<use xlink:href="#id">` pattern [frontend/public/icons.svg1-24](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/public/icons.svg#L1-L24)
- **Favicon**: A custom SVG logo defined in `public/favicon.svg`[frontend/public/favicon.svg1-10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/public/favicon.svg#L1-L10)
- **Hero Imagery**: `src/assets/hero.png` is used in landing sections and workspace headers [frontend/src/assets/hero.png](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/assets/hero.png)

**Sources:**

- [frontend/public/icons.svg1-24](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/public/icons.svg#L1-L24)
- [frontend/public/favicon.svg1-10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/public/favicon.svg#L1-L10)