# Product Sensitivity (Dynamic Pricing) Model
Relevant source files
- [backend/ipynb files/Pricing_Sensitivity_Analysis.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Pricing_Sensitivity_Analysis.ipynb)
- [backend/models/product_sensitivity_dt_model.joblib](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_dt_model.joblib)
- [backend/models/product_sensitivity_label_encoders.joblib](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_label_encoders.joblib)
- [backend/processed_datasets/processed_dynamic_pricing.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_dynamic_pricing.csv)
- [backend/py_files/product_sensitivity_analysis.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py)
- [backend/py_files/product_sensitivity_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py)
- [backend/raw_datasets/dynamic_pricing.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/dynamic_pricing.csv)

The Product Sensitivity (Dynamic Pricing) model is designed to predict the `Historical_Cost_of_Ride` based on supply, demand, and customer-specific features. It utilizes a regression approach to model price sensitivity across different locations and vehicle types, enabling the system to provide dynamic pricing estimates.

## Data Pipeline

The pipeline processes raw ride data through an ETL stage that merges historical pricing with engineered features, followed by categorical encoding to prepare the data for a `DecisionTreeRegressor`.

### Dataset Specifications

- **Raw Dataset**: `backend/raw_datasets/dynamic_pricing.csv` contains 10 columns including supply metrics (`Number_of_Drivers`), demand metrics (`Number_of_Riders`), and ride details [backend/raw_datasets/dynamic_pricing.csv1-218](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/dynamic_pricing.csv#L1-L218)
- **Processed Dataset**: `backend/processed_datasets/processed_dynamic_pricing.csv` contains the feature set used for training, excluding the target variable and high-cardinality metadata [backend/processed_datasets/processed_dynamic_pricing.csv1-10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_dynamic_pricing.csv#L1-L10)

### Data Flow Diagram

This diagram illustrates the flow from raw data ingestion to the generation of serialized model artifacts.

```mermaid
flowchart TD
    subgraph subGraph2 ["Artifact Generation"]
        G["save_artifacts()"]
        H["product_sensitivity_dt_model.joblib"]
        I["product_sensitivity_label_encoders.joblib"]
    end
    subgraph subGraph1 ["Preprocessing & Training"]
        D["label_encode_categoricals()"]
        E["train_decision_tree()"]
        F["DecisionTreeRegressor.fit()"]
    end
    subgraph subGraph0 ["Data Ingestion"]
        A["dynamic_pricing.csv (Raw)"]
        C["load_data()"]
        B["processed_dynamic_pricing.csv"]
    end
    A --> C
    B --> C
    C --> D
    D --> E
    E --> F
    F --> G
    G --> H
    G --> I
```

**Sources**: [backend/py_files/product_sensitivity_analysis.py12-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py#L12-L34)[backend/py_files/product_sensitivity_analysis.py80-91](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py#L80-L91)

## Implementation Details

### Training Pipeline (`product_sensitivity_analysis.py`)

The training script performs a join between the processed features and the raw target column `Historical_Cost_of_Ride`[backend/py_files/product_sensitivity_analysis.py12-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py#L12-L34) It employs `LabelEncoder` for categorical variables such as `Location_Category`, `Customer_Loyalty_Status`, and `Vehicle_Type`[backend/py_files/product_sensitivity_analysis.py37-46](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py#L37-L46)

**Key Components:**

- **Algorithm**: `DecisionTreeRegressor` with a fixed `random_state=42`[backend/py_files/product_sensitivity_analysis.py65](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py#L65-L65)
- **Evaluation**: The model is evaluated using Mean Absolute Error (MAE), Mean Squared Error (MSE), and R² Score [backend/py_files/product_sensitivity_analysis.py69-75](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py#L69-L75)
- **Persistence**: Artifacts are serialized using `joblib.dump`[backend/py_files/product_sensitivity_analysis.py87-88](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py#L87-L88)

### Inference Service (`product_sensitivity_service.py`)

The service layer loads the decision tree and label encoders at module startup [backend/py_files/product_sensitivity_service.py26-33](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py#L26-L33) It defines a `PredictRequest` schema that accepts a dictionary of ride attributes [backend/py_files/product_sensitivity_service.py10-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py#L10-L11)

**Inference Logic:**

1. **Input Preparation**: `prepare_input()` converts the request dictionary into a DataFrame and applies the stored `LabelEncoder` transformations [backend/py_files/product_sensitivity_service.py43-57](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py#L43-L57)
2. **Schema Alignment**: The input is reindexed against `expected_columns` derived from the training dataset to ensure feature order consistency [backend/py_files/product_sensitivity_service.py40-57](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py#L40-L57)
3. **Prediction**: The `predict_product_sensitivity()` function executes the model and returns a float prediction [backend/py_files/product_sensitivity_service.py60-67](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py#L60-L67)

## System Entity Mapping

The following diagram maps the logical components of the Pricing Model to their specific code entities and file locations.

```mermaid
flowchart LR
    subgraph subGraph1 ["Data Entities"]
        RAW_DATA["dynamic_pricing.csv"]
        PROC_DATA["processed_dynamic_pricing.csv"]
    end
    subgraph subGraph0 ["Code Entity Space"]
        PS_SERVICE["product_sensitivity_service.py"]
        PS_ANALYSIS["product_sensitivity_analysis.py"]
        DT_MODEL["product_sensitivity_dt_model.joblib"]
        ENCODERS["product_sensitivity_label_encoders.joblib"]
        PREDICT_FUNC["predict_product_sensitivity()"]
        PREP_FUNC["prepare_input()"]
    end
    RAW_DATA -.-> PS_ANALYSIS
    PROC_DATA -.-> PS_ANALYSIS
    PS_ANALYSIS --> DT_MODEL
    PS_ANALYSIS --> ENCODERS
    DT_MODEL --> PS_SERVICE
    ENCODERS --> PS_SERVICE
    PS_SERVICE --> PREP_FUNC
    PREP_FUNC --> PREDICT_FUNC
```

**Sources**: [backend/py_files/product_sensitivity_analysis.py1-100](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_analysis.py#L1-L100)[backend/py_files/product_sensitivity_service.py1-68](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py#L1-L68)

## Artifact Inventory

| Artifact | Purpose | Format |
| --- | --- | --- |
| `product_sensitivity_dt_model.joblib` | Serialized DecisionTreeRegressor for price prediction. | Joblib Binary [backend/models/product_sensitivity_dt_model.joblib1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_dt_model.joblib#L1-L1) |
| `product_sensitivity_label_encoders.joblib` | Dictionary of LabelEncoders for `Location_Category`, `Customer_Loyalty_Status`, and `Vehicle_Type`. | Joblib Binary [backend/models/product_sensitivity_label_encoders.joblib1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_label_encoders.joblib#L1-L1) |

## Feature Schema

The model expects the following features in the exact order specified during training:

| Feature Name | Type | Description |
| --- | --- | --- |
| `Number_of_Drivers` | Integer | Available supply in the area. |
| `Number_of_Past_Rides` | Integer | Customer ride history count. |
| `Expected_Ride_Duration` | Integer | Estimated time for the trip. |
| `Location_Category` | Categorical | Urban, Suburban, or Rural (Encoded). |
| `Customer_Loyalty_Status` | Categorical | Gold, Silver, or Regular (Encoded). |
| `Vehicle_Type` | Categorical | Economy or Premium (Encoded). |

**Sources**: [backend/processed_datasets/processed_dynamic_pricing.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_dynamic_pricing.csv#L1-L1)[backend/py_files/product_sensitivity_service.py40-57](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py#L40-L57)