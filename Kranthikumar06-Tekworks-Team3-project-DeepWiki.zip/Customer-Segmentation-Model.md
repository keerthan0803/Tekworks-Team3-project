# Customer Segmentation Model
Relevant source files
- [backend/ipynb files/customer_segementation.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb)
- [backend/models/customer_segmentation_gender_encoder.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_gender_encoder.pkl)
- [backend/models/customer_segmentation_kmeans.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_kmeans.pkl)
- [backend/models/customer_segmentation_scaler.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_scaler.pkl)
- [backend/processed_datasets/Mall_Customers.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Mall_Customers.csv)
- [backend/py_files/customer_segmentation.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation.py)
- [backend/py_files/customer_segmentation_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py)
- [backend/raw_datasets/Mall_Customers.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Mall_Customers.csv)

The Customer Segmentation model implements an unsupervised learning pipeline to categorize customers into distinct behavioral groups based on demographic and spending data. It utilizes the KMeans clustering algorithm and provides a visual context for predictions using t-SNE (t-Distributed Stochastic Neighbor Embedding) to map high-dimensional input into a 2D coordinate space.

## Data Pipeline

The model consumes the `Mall_Customers.csv` dataset, which contains attributes for 200 customers [backend/ipynb files/customer_segementation.ipynb110-111](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb#L110-L111)

### Raw Dataset Structure

The raw data contains the following features:

- `CustomerID`: Unique identifier (dropped during preprocessing) [backend/ipynb files/customer_segementation.ipynb148-149](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb#L148-L149)
- `Gender`: Categorical (Male/Female).
- `Age`: Numerical.
- `Annual Income (k$)`: Numerical.
- `Spending Score (1-100)`: Numerical.

[backend/raw_datasets/Mall_Customers.csv1-10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Mall_Customers.csv#L1-L10)

### Preprocessing and Training

The training script `customer_segmentation.py` performs the following steps:

1. **Encoding**: Converts the `Gender` column into numerical values using `LabelEncoder`[backend/py_files/customer_segmentation.py23-24](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation.py#L23-L24)
2. **Scaling**: Applies `StandardScaler` to all features to ensure the distance-based KMeans algorithm treats features equally [backend/py_files/customer_segmentation.py26-27](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation.py#L26-L27)
3. **Clustering**: Initializes a `KMeans` model with `n_clusters=4`[backend/py_files/customer_segmentation.py29-30](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation.py#L29-L30)

**Sources:**[backend/py_files/customer_segmentation.py10-37](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation.py#L10-L37)[backend/ipynb files/customer_segementation.ipynb158-162](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb#L158-L162)

## Model Artifacts

The training process generates three distinct artifacts stored in the `backend/models/` directory:

| Artifact Name | Type | Purpose |
| --- | --- | --- |
| `customer_segmentation_kmeans.pkl` | KMeans Model | Stores cluster centroids and assignments [backend/models/customer_segmentation_kmeans.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_kmeans.pkl#L1-L3) |
| `customer_segmentation_scaler.pkl` | StandardScaler | Normalizes input data for inference [backend/models/customer_segmentation_scaler.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_scaler.pkl#L1-L3) |
| `customer_segmentation_gender_encoder.pkl` | LabelEncoder | Maps "Male"/"Female" strings to training-time integers [backend/models/customer_segmentation_gender_encoder.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_gender_encoder.pkl#L1-L3) |

**Sources:**[backend/py_files/customer_segmentation.py32-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation.py#L32-L34)

## Inference Service

The `customer_segmentation_service.py` module handles real-time requests. Unlike supervised models in this project, this service also computes t-SNE coordinates for the input point relative to the original training distribution to support frontend visualization.

### Coordinate Computation

The function `compute_tsne_point` merges the new input with the training dataset to calculate a 2D projection:
[backend/py_files/customer_segmentation_service.py56-66](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L56-L66)

### Segment Labels

The model maps the numerical cluster indices (0-3) to human-readable labels:

- **0**: At-Risk Customers
- **1**: Occasional Customers
- **2**: Regular Customers
- **3**: High-Value Customers

[backend/py_files/customer_segmentation_service.py92-97](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L92-L97)

### System Flow: Request to Segment

The following diagram illustrates how the `PredictRequest` is transformed into a labeled segment and t-SNE coordinates.

**Customer Segmentation Inference Flow**

```mermaid
flowchart TD
    K["Final JSON Response"]
    subgraph subGraph3 ["Visualization Logic"]
        H["compute_tsne_point()"]
        I["training_data"]
        J["t-SNE X, Y Coords"]
    end
    subgraph subGraph2 ["Clustering Logic"]
        F["kmeans_model.predict()"]
        G["Segment Mapping (0-3)"]
    end
    subgraph Preprocessing
        C["gender_encoder.transform()"]
        D["reindex(expected_columns)"]
        E["scaler.transform()"]
    end
    subgraph subGraph0 ["Request Handling"]
        A["PredictRequest (JSON)"]
        B["prepare_input()"]
    end
    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
    F --> G
    E --> H
    I --> H
    H --> J
    G --> K
    J --> K
```

**Sources:**[backend/py_files/customer_segmentation_service.py39-103](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L39-L103)

## Code Entity Mapping

This diagram bridges the gap between the logical segmentation process and the specific Python entities in the codebase.

**Logic to Code Entity Mapping**

```mermaid
classDiagram
    class customer_segmentation_py {
        <<Script>>
        +train_and_save()
    }
    class customer_segmentation_service_py {
        <<Service>>
        +prepare_input(data)
        +compute_tsne_point(scaled_training, scaled_input_row)
        +predict_customer_segmentation(request)
    }
    class Artifacts {
        +kmeans_model
        +scaler
        +gender_encoder
    }
    class DataObjects {
        +PredictRequest
        +training_data(Mall_Customers.csv)
    }
    customer_segmentation_py ..> Artifacts : "Generates via joblib.dump()"
    customer_segmentation_service_py ..> Artifacts : "Loads via joblib.load()"
    customer_segmentation_service_py ..> DataObjects : "Uses for t-SNE & Schema"
```

**Sources:**[backend/py_files/customer_segmentation.py10-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation.py#L10-L34)[backend/py_files/customer_segmentation_service.py11-36](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L11-L36)

### Key Functions

- `prepare_input`: Handles `LabelEncoder` transformation for the "Gender" field and ensures column alignment [backend/py_files/customer_segmentation_service.py39-53](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L39-L53)
- `predict_customer_segmentation`: The main entry point that orchestrates scaling, cluster prediction, and t-SNE calculation [backend/py_files/customer_segmentation_service.py69-103](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L69-L103)
- `compute_tsne_point`: Utilizes `sklearn.manifold.TSNE` to generate a 2D representation of the high-dimensional customer data [backend/py_files/customer_segmentation_service.py56-66](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L56-L66)

**Sources:**[backend/py_files/customer_segmentation_service.py1-103](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L1-L103)