# Raw Datasets
Relevant source files
- [backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv)
- [backend/raw_datasets/Mall_Customers.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Mall_Customers.csv)
- [backend/raw_datasets/Telco_customer_churn.xlsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Telco_customer_churn.xlsx)
- [backend/raw_datasets/Time_Series_Forcasting.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Time_Series_Forcasting.csv)
- [backend/raw_datasets/campaign_responses.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/campaign_responses.csv)
- [backend/raw_datasets/dynamic_pricing.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/dynamic_pricing.csv)
- [backend/raw_datasets/subscription_dataset.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/subscription_dataset.csv)
- [backend/requirements.txt](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt)

This page documents the source data layer for the Tekworks Team3 ML platform. The `backend/raw_datasets/` directory contains eight files in various formats (CSV, XLSX) that serve as the ground truth for training the platform's seven predictive models. These datasets are ingested by Jupyter notebooks in `backend/ipynb files/` for exploratory data analysis (EDA) and feature engineering.

## Data Inventory & Model Mapping

The following table summarizes the relationship between raw data files and the inference services they support.

| File Name | Format | Target Model | Key Features |
| --- | --- | --- | --- |
| `Telco_customer_churn.xlsx` | XLSX | Churn Prediction | Tenure, Monthly Charges, Total Charges, Contract |
| `WA_Fn-UseC_-Telco-Customer-Churn.csv` | CSV | Subscription Renewal | tenure, Contract, MonthlyCharges, TechSupport |
| `campaign_responses.csv` | CSV | Market Response | age, annual_income, credit_score, employed |
| `Time_Series_Forcasting.csv` | CSV | Product Demand | Units_Sold, Revenue, Marketing_Spend, Temperature |
| `dynamic_pricing.csv` | CSV | Product Sensitivity | Number_of_Riders, Number_of_Drivers, Vehicle_Type |
| `Customer_Attributes_and_Purchase_Propensity.csv` | CSV | Purchase Propensity | Age, Income, City, Marital_Status, Score |
| `Mall_Customers.csv` | CSV | Customer Segmentation | Gender, Age, Annual Income, Spending Score |
| `subscription_dataset.csv` | CSV | Subscription (Alt) | age, subscription_type, monthly_fee, tenure_months |

**Sources:**[backend/raw_datasets/Mall_Customers.csv1-201](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Mall_Customers.csv#L1-L201)[backend/raw_datasets/dynamic_pricing.csv1-112](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/dynamic_pricing.csv#L1-L112)[backend/raw_datasets/Time_Series_Forcasting.csv1-65](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Time_Series_Forcasting.csv#L1-L65)[backend/raw_datasets/campaign_responses.csv1-57](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/campaign_responses.csv#L1-L57)[backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv1-153](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv#L1-L153)

## Data Flow Architecture

The raw datasets are the entry point of the machine learning lifecycle. They are processed into cleaned CSVs before being used to train the serialized artifacts.

### From Raw Data to Inference

This diagram maps the raw data files to their corresponding training scripts and the Pydantic request models used in the API.

```mermaid
flowchart LR
    subgraph subGraph2 ["Code Entity Space (API)"]
        R1["ChurnRequest"]
        R2["MarketResponseRequest"]
        R3["SegmentationRequest"]
        R4["SensitivityRequest"]
    end
    subgraph subGraph1 ["Code Entity Space (Training)"]
        T1["churn.py"]
        T2["market_responce.py"]
        T3["customer_segmentation.py"]
        T4["product_sensitivity_analysis.py"]
    end
    subgraph subGraph0 ["Raw Dataset Space"]
        D1["Telco_customer_churn.xlsx"]
        D2["campaign_responses.csv"]
        D3["Mall_Customers.csv"]
        D4["dynamic_pricing.csv"]
    end
    D1 --> T1
    D2 --> T2
    D3 --> T3
    D4 --> T4
    T1 -.-> R1
    T2 -.-> R2
    T3 -.-> R3
    T4 -.-> R4
```

**Sources:**[backend/raw_datasets/Mall_Customers.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Mall_Customers.csv#L1-L1)[backend/raw_datasets/dynamic_pricing.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/dynamic_pricing.csv#L1-L1)[backend/raw_datasets/campaign_responses.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/campaign_responses.csv#L1-L1)

## Dataset Specifications

### 1. Customer Segmentation (`Mall_Customers.csv`)

Used for unsupervised K-Means clustering.

- **Columns:**`CustomerID`, `Gender`, `Age`, `Annual Income (k$)`, `Spending Score (1-100)`[backend/raw_datasets/Mall_Customers.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Mall_Customers.csv#L1-L1)
- **Implementation:** Fed into `customer_segmentation.py` to produce 4 distinct clusters: At-Risk, Occasional, Regular, and High-Value.

### 2. Product Sensitivity (`dynamic_pricing.csv`)

Used for regression analysis of ride costs.

- **Columns:**`Number_of_Riders`, `Number_of_Drivers`, `Location_Category`, `Customer_Loyalty_Status`, `Number_of_Past_Rides`, `Average_Ratings`, `Time_of_Booking`, `Vehicle_Type`, `Expected_Ride_Duration`, `Historical_Cost_of_Ride`[backend/raw_datasets/dynamic_pricing.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/dynamic_pricing.csv#L1-L1)
- **Implementation:** The `Historical_Cost_of_Ride` serves as the target variable for the DecisionTreeRegressor.

### 3. Product Demand (`Time_Series_Forcasting.csv`)

Contains historical sales data with environmental factors.

- **Columns:**`Date`, `Product_ID`, `Units_Sold`, `Revenue`, `Marketing_Spend`, `Holiday_Indicator`, `Temperature`, `Fuel_Price`, `Consumer_Confidence`, `Season`, `Forecast_Demand`[backend/raw_datasets/Time_Series_Forcasting.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Time_Series_Forcasting.csv#L1-L1)
- **Implementation:** Used by `product_demand.py` to train a RandomForestRegressor.

### 4. Market Response (`campaign_responses.csv`)

Binary classification dataset for marketing campaign success.

- **Columns:**`customer_id`, `age`, `gender`, `annual_income`, `credit_score`, `employed`, `marital_status`, `no_of_children`, `responded`[backend/raw_datasets/campaign_responses.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/campaign_responses.csv#L1-L1)
- **Implementation:** The `responded` column (Yes/No) is the target for Logistic Regression in `market_responce.py`.

### 5. Purchase Propensity (`Customer_Attributes_and_Purchase_Propensity.csv`)

Predicts the likelihood of a customer making a purchase.

- **Columns:**`Age`, `Income`, `City`, `Marital_Status`, `Score`, `Purchased`[backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv#L1-L1)
- **Implementation:** Categorical variables like `City` and `Marital_Status` are label-encoded during the training phase in `purchase_propensity.py`.

## Technical Dependencies for Ingestion

To process these raw files, the backend requires specific libraries defined in `requirements.txt`:

- `pandas`: For CSV and general data manipulation [backend/requirements.txt1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L1)
- `openpyxl`: Required specifically for reading the `.xlsx` churn dataset [backend/requirements.txt9](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L9-L9)
- `scikit-learn`: For preprocessing steps like scaling and encoding [backend/requirements.txt6](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L6-L6)

### Data Ingestion Pipeline

```mermaid
flowchart LR
    subgraph subGraph2 ["Internal State"]
        DF["pd.DataFrame"]
    end
    subgraph subGraph1 ["Processing Logic"]
        PD["import pandas as pd"]
        XL["import openpyxl"]
    end
    subgraph Filesystem
        RAW["raw_datasets/*.csv"]
        XLS["raw_datasets/*.xlsx"]
    end
    RAW --> PD
    XLS --> XL
    XL --> PD
    PD --> DF
```

**Sources:**[backend/requirements.txt1-9](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L9)