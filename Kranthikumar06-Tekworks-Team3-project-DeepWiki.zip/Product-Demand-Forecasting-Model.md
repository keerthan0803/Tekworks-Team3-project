# Product Demand Forecasting Model
Relevant source files
- [backend/ipynb files/product.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/product.ipynb)
- [backend/models/product_demand_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_demand_model.pkl)
- [backend/models/product_demand_scaler.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_demand_scaler.pkl)
- [backend/processed_datasets/processed_product_demand_forcasting.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_product_demand_forcasting.csv)
- [backend/py_files/product_demand.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand.py)
- [backend/py_files/product_demand_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py)
- [backend/raw_datasets/Time_Series_Forcasting.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Time_Series_Forcasting.csv)

The Product Demand Forecasting Model is a regression-based pipeline designed to predict future product demand (continuous float values) based on historical sales data, marketing spend, and external environmental factors such as seasonality and consumer confidence.

## 1. Data Pipeline

The model utilizes a two-stage data lifecycle where raw time-series data is transformed into a feature set suitable for a `RandomForestRegressor`.

### 1.1 Raw Dataset

The primary data source is `Time_Series_Forcasting.csv`, which contains 10,000 entries [backend/ipynb files/product.ipynb187](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/product.ipynb#L187-L187) The dataset includes temporal markers, product identifiers, and economic indicators.

| Column | Type | Description |
| --- | --- | --- |
| `Date` | int64 | Sequential time index [backend/raw_datasets/Time_Series_Forcasting.csv2](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Time_Series_Forcasting.csv#L2-L2) |
| `Units_Sold` | float64 | Historical units sold |
| `Revenue` | float64 | Revenue generated |
| `Marketing_Spend` | float64 | Budget allocated to marketing |
| `Holiday_Indicator` | int64 | Binary flag (1 for holiday, 0 otherwise) |
| `Season` | int64 | Categorical encoding of the season |
| `Forecast_Demand` | float64 | The target variable for prediction |

### 1.2 Preprocessing and Feature Engineering

During the transformation process in `product.ipynb` and the training script `product_demand.py`, the following key steps are performed:

- **Date Exclusion:** The `Date` column is explicitly dropped to prevent the model from leaking sequential ordering, ensuring it learns from features rather than just a time-index trend [backend/py_files/product_demand.py28-31](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand.py#L28-L31)
- **Feature Selection:** The model focuses on `Units_Sold`, `Revenue`, `Marketing_Spend`, `Holiday_Indicator`, and `Season`[backend/processed_datasets/processed_product_demand_forcasting.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_product_demand_forcasting.csv#L1-L1)
- **Scaling:** Features are normalized using `StandardScaler` to ensure uniform variance across disparate units (e.g., Revenue vs. Units_Sold) [backend/py_files/product_demand.py40-42](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand.py#L40-L42)

## 2. Model Architecture

The forecasting engine uses a Random Forest Regressor, chosen for its ability to handle non-linear relationships between marketing spend and demand.

### 2.1 Training Implementation

The training script [backend/py_files/product_demand.py11-54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand.py#L11-L54) performs the following:

1. **Data Loading:** Reads from `processed_product_demand_forcasting.csv`.
2. **Split:** Uses an 80/20 train-test split with a fixed `random_state=42`[backend/py_files/product_demand.py36-38](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand.py#L36-L38)
3. **Hyperparameters:** Initializes a `RandomForestRegressor` with `n_estimators=200`[backend/py_files/product_demand.py44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand.py#L44-L44)
4. **Artifact Generation:** Saves the trained model and the fitted scaler as `.pkl` files using the `pickle` library [backend/py_files/product_demand.py47-51](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand.py#L47-L51)

### 2.2 Model Training Flow

The following diagram illustrates the transition from raw data to serialized model artifacts.

**Data to Artifact Pipeline**

```mermaid
flowchart TD
    subgraph subGraph2 ["Artifact Space"]
        MODEL_PKL["product_demand_model.pkl"]
        SCALER_PKL["product_demand_scaler.pkl"]
    end
    subgraph subGraph1 ["Code Entity: product_demand.py"]
        LOAD["pd.read_csv()"]
        DROP["Drop 'Date' & 'Forecast_Demand'"]
        SPLIT["train_test_split()"]
        SCALE["StandardScaler.fit_transform()"]
        TRAIN["RandomForestRegressor.fit()"]
    end
    subgraph subGraph0 ["Data Space"]
        RAW["Time_Series_Forcasting.csv"]
        PROC["processed_product_demand_forcasting.csv"]
    end
    RAW --> PROC
    PROC --> LOAD
    LOAD --> DROP
    DROP --> SPLIT
    SPLIT --> SCALE
    SCALE --> TRAIN
    TRAIN --> MODEL_PKL
    SCALE --> SCALER_PKL
```

Sources: [backend/py_files/product_demand.py11-54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand.py#L11-L54)[backend/processed_datasets/processed_product_demand_forcasting.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_product_demand_forcasting.csv#L1-L1)

## 3. Inference Service

The `product_demand_service.py` module provides the interface for real-time predictions. It loads artifacts at startup to minimize latency during API calls.

### 3.1 Loading Logic

The `load_bundle()` function [backend/py_files/product_demand_service.py17-53](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L17-L53) is responsible for:

- Loading `product_demand_model.pkl`[backend/py_files/product_demand_service.py28-29](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L28-L29)
- Loading `product_demand_scaler.pkl`[backend/py_files/product_demand_service.py34-35](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L34-L35)
- Determining `expected_columns` by inspecting the training dataset to ensure the input DataFrame matches the model's expected feature order [backend/py_files/product_demand_service.py51-53](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L51-L53)

### 3.2 Prediction Workflow

When a request is received, the service follows these steps:

1. **Input Preparation:** Converts the request dictionary into a DataFrame and reindexes it to match `expected_columns`[backend/py_files/product_demand_service.py59-61](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L59-L61)
2. **Scaling:** Applies the pre-loaded scaler to the input data [backend/py_files/product_demand_service.py69](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L69-L69)
3. **Inference:** Calls the `predict()` method of the Random Forest model [backend/py_files/product_demand_service.py70](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L70-L70)
4. **Formatting:** Returns a JSON-compatible dictionary containing the float prediction [backend/py_files/product_demand_service.py72](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L72-L72)

### 3.3 Inference Sequence Diagram

This diagram maps the FastAPI request flow to specific internal service functions.

**Request Processing Flow**

```mermaid
sequenceDiagram
    participant API as backend/app.py
    participant SVC as product_demand_service.py
    participant MDL as product_demand_model.pkl
    API->>SVC: predict_product_demand(PredictRequest)
    SVC->>SVC: prepare_input(data, expected_columns)
    Note over SVC: Uses pd.DataFrame.reindex()
    SVC->>SVC: bundle["scaler"].transform(input_df)
    SVC->>MDL: bundle["model"].predict(scaled_input)
    MDL-->>SVC: ndarray([prediction])
    SVC-->>API: {"prediction": float}
```

Sources: [backend/py_files/product_demand_service.py59-72](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L59-L72)[backend/app.py1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L1-L1)

## 4. Artifact Inventory

The following artifacts are required for the service to function. They are managed via Git LFS due to their size.

| Artifact | Role | Path |
| --- | --- | --- |
| **Model** | Random Forest Regressor | [backend/models/product_demand_model.pkl1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_demand_model.pkl#L1-L4) |
| **Scaler** | Feature Normalization | [backend/models/product_demand_scaler.pkl1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_demand_scaler.pkl#L1-L4) |
| **Data Reference** | Column alignment source | [backend/processed_datasets/processed_product_demand_forcasting.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_product_demand_forcasting.csv#L1-L1) |

Sources: [backend/py_files/product_demand_service.py18-25](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L18-L25)