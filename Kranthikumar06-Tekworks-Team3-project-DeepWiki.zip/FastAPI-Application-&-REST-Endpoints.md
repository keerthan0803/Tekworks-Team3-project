# FastAPI Application & REST Endpoints
Relevant source files
- [backend/app.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py)
- [backend/py_files/churn_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py)
- [backend/py_files/customer_segmentation_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py)
- [backend/py_files/market_response_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py)
- [backend/py_files/product_demand_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py)
- [backend/py_files/product_sensitivity_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py)
- [backend/py_files/purchase_propensity_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py)
- [backend/py_files/subscription_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py)

This page provides a detailed technical reference for the FastAPI backend application located in `backend/app.py`. It serves as the central hub for the Tekworks Team3 ML platform, orchestrating request routing to seven specialized machine learning inference services.

## Application Initialization & Configuration

The application is built using the `FastAPI` framework [backend/app.py1-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L1-L7) It utilizes a dynamic path configuration to allow modular service loading and implements a permissive CORS policy to support the Vite-based frontend.

### Dynamic Service Loading

To maintain a clean directory structure, all ML inference logic is housed in `backend/py_files/`. The application dynamically adds this directory to `sys.path`[backend/app.py17-18](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L17-L18) This allows `app.py` to import service modules directly as if they were in the root backend directory [backend/app.py20-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L20-L44)

### CORS Middleware

The application implements `CORSMiddleware` to handle Cross-Origin Resource Sharing. In the current development configuration, it is configured with broad permissions:

- **Allow Origins**: `["*"]` (All origins permitted) [backend/app.py11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L11-L11)
- **Allow Methods/Headers**: `["*"]` (All standard HTTP methods and headers) [backend/app.py13-14](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L13-L14)

### System Component Diagram

The following diagram illustrates the relationship between the FastAPI entry point, the system path manipulation, and the underlying service modules.

**Backend Service Hub Architecture**

```mermaid
flowchart LR
    subgraph subGraph1 ["Inference Services (py_files/)"]
        D["churn_service.py"]
        E["subscription_service.py"]
        F["market_response_service.py"]
        G["product_demand_service.py"]
        H["product_sensitivity_service.py"]
        I["purchase_propensity_service.py"]
        J["customer_segmentation_service.py"]
    end
    subgraph subGraph0 ["FastAPI Application (app.py)"]
        A["app = FastAPI()"]
        B["CORS Middleware"]
        C["sys.path.append('py_files')"]
    end
    A --> B
    A --> C
    C -.->|"Enables Imports"| D
    C -.->|"Enables Imports"| E
    C -.->|"Enables Imports"| F
    C -.->|"Enables Imports"| G
    C -.->|"Enables Imports"| H
    C -.->|"Enables Imports"| I
    C -.->|"Enables Imports"| J
```

**Sources:**[backend/app.py1-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L1-L44)

---

## Request/Response Schemas

The application uses Pydantic models to enforce strict typing on incoming JSON payloads.

### The PredictRequest Pattern

Six of the seven endpoints follow a standard `PredictRequest` pattern where the features are wrapped in a `data` dictionary. This allows for flexible feature sets without changing the Pydantic class definition.

| Service Module | Alias in `app.py` | Schema Structure |
| --- | --- | --- |
| `churn_service` | `ChurnRequest` | `{"data": Dict[str, Any]}` |
| `subscription_service` | `SubscriptionRequest` | `{"data": Dict[str, Any]}` |
| `product_demand_service` | `ProductDemandRequest` | `{"data": Dict[str, Any]}` |
| `product_sensitivity_service` | `ProductSensitivityRequest` | `{"data": Dict[str, Any]}` |
| `purchase_propensity_service` | `PurchasePropensityRequest` | `{"data": Dict[str, Any]}` |
| `customer_segmentation_service` | `CustomerSegmentationRequest` | `{"data": Dict[str, Any]}` |

**Sources:**[backend/py_files/purchase_propensity_service.py11-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L11-L12)[backend/py_files/subscription_service.py12-13](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L12-L13)[backend/app.py20-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L20-L44)

### MarketResponseRequest Exception

The `market_response_service` uses a flat schema rather than a `data` wrapper, explicitly defining every feature field.

| Field | Type | Source |
| --- | --- | --- |
| `age` | `int` | [backend/py_files/market_response_service.py26](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L26-L26) |
| `annual_income` | `float` | [backend/py_files/market_response_service.py27](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L27-L27) |
| `credit_score` | `int` | [backend/py_files/market_response_service.py28](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L28-L28) |
| `no_of_children` | `int` | [backend/py_files/market_response_service.py29](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L29-L29) |
| `gender` | `Union[int, str]` | [backend/py_files/market_response_service.py30](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L30-L30) |
| `employed` | `Union[int, str]` | [backend/py_files/market_response_service.py31](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L31-L31) |
| `marital_status` | `Union[int, str]` | [backend/py_files/market_response_service.py32](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L32-L32) |

---

## REST Endpoints

The application exposes one GET health check and seven POST prediction routes.

### Health Check

- **Endpoint**: `GET /`
- **Function**: `health_check()`
- **Returns**: `{"status": "ok"}`
- **Source**: [backend/app.py47-49](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L47-L49)

### Prediction Routes

Each prediction route receives a validated Pydantic object and passes it to the corresponding service function imported from `py_files/`.

| Method | Path | Service Function | Request Model |
| --- | --- | --- | --- |
| POST | `/predict/churn` | `predict_churn` | `ChurnRequest` |
| POST | `/predict/subscription` | `predict_subscription` | `SubscriptionRequest` |
| POST | `/predict/market` | `predict_market_response` | `MarketResponseRequest` |
| POST | `/predict/product-demand` | `predict_product_demand` | `ProductDemandRequest` |
| POST | `/predict/product-sensitivity` | `predict_product_sensitivity` | `ProductSensitivityRequest` |
| POST | `/predict/purchase-propensity` | `predict_purchase_propensity` | `PurchasePropensityRequest` |
| POST | `/predict/customer-segmentation` | `predict_customer_segmentation` | `CustomerSegmentationRequest` |

**Sources:**[backend/app.py52-90](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L52-L90)

---

## Data Flow: From Request to Prediction

The following diagram bridges the Natural Language concepts of "User Input" and "Prediction Result" to the specific Code Entities that process them within the FastAPI framework.

**Request Processing Pipeline**

```mermaid
sequenceDiagram
    participant U as "Frontend User"
    participant A as "app.py (FastAPI)"
    participant S as "Service Module (e.g., purchase_propensity_service.py)"
    participant M as "Model Artifact (.pkl/.joblib)"
    U->>A: "POST /predict/purchase-propensity" {data: {...}}
    A->>A: "PurchasePropensityRequest" (Validation)
    A->>S: "predict_purchase_propensity(request)"
    S->>S: "prepare_input(request.data)" (Preprocessing)
    S->>M: "purchase_model.predict(scaled_input)"
    M-->>S: "prediction_val (0 or 1)"
    S->>S: "Map labels (e.g., 'Purchased')"
    S-->>A: "Dict[str, Any]"
    A-->>U: "JSON Response"
```

**Sources:**[backend/app.py79-83](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L79-L83)[backend/py_files/purchase_propensity_service.py64-101](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L64-L101)

### Key Implementation Details in Services

1. **Fail-Fast Startup**: Services load their artifacts (`.pkl` or `.joblib`) at the module level. If files are missing, they raise a `RuntimeError` immediately [backend/py_files/purchase_propensity_service.py30-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L30-L34)[backend/py_files/customer_segmentation_service.py25-29](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L25-L29)
2. **Preprocessing**: Each service includes a `prepare_input` function that converts the request dictionary into a `pandas.DataFrame`, applies encoding, and reindexes to match the `expected_columns` from training [backend/py_files/subscription_service.py53-74](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L53-L74)[backend/py_files/product_demand_service.py59-61](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_demand_service.py#L59-L61)
3. **Error Handling**: If invalid categorical values are provided that the encoders cannot process, the services raise a `FastAPI.HTTPException` with a 400 status code [backend/py_files/product_sensitivity_service.py51-57](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/product_sensitivity_service.py#L51-L57)
4. **Probability Extraction**: Where supported by the model (e.g., Logistic Regression), the service extracts the probability using `predict_proba` and includes it in the response [backend/py_files/churn_service.py80-83](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L80-L83)

**Sources:**[backend/py_files/purchase_propensity_service.py15-101](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L15-L101)[backend/py_files/subscription_service.py16-109](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L16-L109)[backend/py_files/churn_service.py15-84](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L15-L84)