# Processed Datasets & Jupyter Notebooks
Relevant source files
- [.gitignore](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitignore)
- [backend/ipynb files/Pricing_Sensitivity_Analysis.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Pricing_Sensitivity_Analysis.ipynb)
- [backend/ipynb files/Purchase_Propensity_Modeling.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Purchase_Propensity_Modeling.ipynb)
- [backend/ipynb files/churn_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb)
- [backend/ipynb files/customer_segementation.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb)
- [backend/ipynb files/market_responce.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/market_responce.ipynb)
- [backend/ipynb files/product.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/product.ipynb)
- [backend/ipynb files/subscription_renewal_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/subscription_renewal_prediction.ipynb)
- [backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv)
- [backend/processed_datasets/Mall_Customers.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Mall_Customers.csv)
- [backend/processed_datasets/churn_prediction_data.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/churn_prediction_data.csv)
- [backend/processed_datasets/processed_dynamic_pricing.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_dynamic_pricing.csv)
- [backend/processed_datasets/processed_product_demand_forcasting.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_product_demand_forcasting.csv)
- [backend/processed_datasets/subscription_renewal_data.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/subscription_renewal_data.csv)
- [backend/py_files/subscription.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py)
- [backend/raw_datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv)

This page documents the data transformation layer of the Tekworks Team3 project. It details the transition from raw data ingestion to model-ready features, specifically focusing on the Jupyter notebooks used for Exploratory Data Analysis (EDA) and the resulting processed CSV files stored in `backend/processed_datasets/`.

## Data Transformation Pipeline

The project follows a structured ETL (Extract, Transform, Load) pipeline where raw datasets are cleaned, encoded, and filtered within Jupyter notebooks. These notebooks serve as the experimental playground where feature selection and engineering decisions are finalized before being codified into training scripts.

### High-Level Data Flow

The diagram below illustrates how raw data is converted into processed artifacts that bridge the gap between experimentation and production training.

**Data Bridge: Notebooks to Training**

```mermaid
flowchart LR
    subgraph subGraph3 ["Code Entity Space (Training Scripts)"]
        T1["subscription.py"]
        T2["customer_segmentation.py"]
        T3["purchase_propensity.py"]
    end
    subgraph subGraph2 ["Processed Data Space"]
        P1["subscription_renewal_data.csv"]
        P2["Mall_Customers.csv (Processed)"]
        P3["Purchase_Propensity_processed.csv"]
    end
    subgraph subGraph1 ["Transformation Layer (Jupyter)"]
        N1["subscription_renewal_prediction.ipynb"]
        N2["customer_segementation.ipynb"]
        N3["Purchase_Propensity_Modeling.ipynb"]
    end
    subgraph subGraph0 ["Raw Data Space"]
        R1["WA_Fn-UseC_-Telco-Customer-Churn.csv"]
        R2["Mall_Customers.csv"]
        R3["Customer_Attributes_and_Purchase_Propensity.csv"]
    end
    R1 --> N1
    N1 --> P1
    P1 --> T1
    R2 --> N2
    N2 --> P2
    P2 --> T2
    R3 --> N3
    N3 --> P3
    P3 --> T3
```

**Sources:**[backend/ipynb files/subscription_renewal_prediction.ipynb1-24](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/subscription_renewal_prediction.ipynb#L1-L24)[backend/ipynb files/customer_segementation.ipynb110-149](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb#L110-L149)[backend/ipynb files/Purchase_Propensity_Modeling.ipynb116-160](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Purchase_Propensity_Modeling.ipynb#L116-L160)

---

## Jupyter Notebooks Analysis

The notebooks in `backend/ipynb files/` perform the heavy lifting of data preparation. Key strategies across these notebooks include:

### 1. Feature Selection & Dropping

Notebooks identify and remove high-cardinality identifiers or irrelevant metadata that do not contribute to predictive power.

- **Churn Prediction:** Drops `CustomerID`, `Count`, `Country`, `State`, `Lat Long`, `Latitude`, `Longitude`, `Churn Score`, `CLTV`, and `Churn Reason`[backend/ipynb files/churn_prediction.ipynb52-98](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb#L52-L98)
- **Customer Segmentation:** Removes `CustomerID` as it is a non-informative index [backend/ipynb files/customer_segementation.ipynb147-149](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb#L147-L149)
- **Product Demand:** Excludes the `Date` column to focus on numerical and categorical drivers [backend/ipynb files/product.ipynb191-203](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/product.ipynb#L191-L203)

### 2. Categorical Encoding Strategies

Two primary strategies are employed depending on the model requirements:

- **Manual/Label Encoding:** Used in `Purchase_Propensity_Modeling.ipynb` and `customer_segementation.ipynb` using `sklearn.preprocessing.LabelEncoder` to convert categorical strings (like `Gender` or `City`) into integers [backend/ipynb files/customer_segementation.ipynb158-162](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb#L158-L162)[backend/ipynb files/Purchase_Propensity_Modeling.ipynb154-160](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Purchase_Propensity_Modeling.ipynb#L154-L160)
- **One-Hot Encoding (get_dummies):** Extensively used for models where categorical variables do not have an ordinal relationship, such as `Contract` or `Payment Method` in churn modeling.

### 3. Null Handling & Data Cleaning

- **Subscription Renewal:** Checks for missing values and ensures data types are consistent for `MonthlyCharges` and `TotalCharges`[backend/ipynb files/subscription_renewal_prediction.ipynb197-205](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/subscription_renewal_prediction.ipynb#L197-L205)
- **Customer Segmentation:** Validates that no missing values exist using `df.isnull().sum()` before proceeding to KMeans clustering [backend/ipynb files/customer_segementation.ipynb214-216](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb#L214-L216)

---

## Processed Datasets Reference

The following table details the six core processed files located in `backend/processed_datasets/` and their schema after transformation.

| Processed File | Target Model | Key Features | Implementation Note |
| --- | --- | --- | --- |
| `subscription_renewal_data.csv` | Subscription Renewal | `tenure`, `Contract`, `MonthlyCharges`, `InternetService` | Filtered to 7 core columns [backend/processed_datasets/subscription_renewal_data.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/subscription_renewal_data.csv#L1-L1) |
| `Mall_Customers.csv` | Segmentation | `Gender`, `Age`, `Annual Income`, `Spending Score` | `CustomerID` removed [backend/processed_datasets/Mall_Customers.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Mall_Customers.csv#L1-L1) |
| `Purchase_Propensity_processed.csv` | Purchase Propensity | `Age`, `Income`, `City`, `Marital_Status`, `Score` | Cleaned numerical attributes [backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv#L1-L1) |
| `processed_dynamic_pricing.csv` | Product Sensitivity | `Number_of_Drivers`, `Expected_Ride_Duration`, `Vehicle_Type` | Targets `Historical_Cost_of_Ride`[backend/processed_datasets/processed_dynamic_pricing.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_dynamic_pricing.csv#L1-L1) |
| `processed_product_demand_forcasting.csv` | Product Demand | `Units_Sold`, `Revenue`, `Marketing_Spend`, `Season` | Time-series features extracted [backend/processed_datasets/processed_product_demand_forcasting.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/processed_product_demand_forcasting.csv#L1-L1) |
| `churn_prediction_data.csv` | Churn Prediction | `Senior Citizen`, `Tenure Months`, `Contract`, `Monthly Charges` | Simplified Telco schema [backend/processed_datasets/churn_prediction_data.csv1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/churn_prediction_data.csv#L1-L1) |

---

## ETL Implementation Details

### Label Encoding Bridge

The `LabelEncoder` logic in the notebooks is mirrored in the production inference services. For example, the transformation of `Gender` in `customer_segementation.ipynb` is the precursor to the `gender_encoder.pkl` artifact used by the backend.

**Entity Mapping: Categorical Processing**

```mermaid
classDiagram
    class JupyterNotebook {
        +pd.read_csv()
        +df.drop()
        +LabelEncoder.fit_transform()
        +df.to_csv()
    }
    class ProcessedCSV {
        +NumericalColumns
        +EncodedCategoricals
    }
    class TrainingScript {
        +pd.read_csv()
        +Model.fit()
        +pickle.dump()
    }
    JupyterNotebook --> ProcessedCSV : "Exports Clean Data"
    ProcessedCSV --> TrainingScript : "Feeds Training Loop"
```

**Sources:**[backend/ipynb files/customer_segementation.ipynb158-162](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb#L158-L162)[backend/processed_datasets/Mall_Customers.csv1-6](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Mall_Customers.csv#L1-L6)[backend/py_files/subscription.py1-17](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py#L1-L17)

### Feature Binning and Dropping

In `churn_prediction.ipynb`, complex location data (Latitude/Longitude) is dropped in favor of broader categorical labels, and the `Churn Value` (numeric) is often used as the training target while `Churn Label` (string) is kept for human-readable processed files [backend/ipynb files/churn_prediction.ipynb68-98](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb#L68-L98)

### Bridge to Training Scripts

The processed CSVs serve as the definitive source of truth for the standalone Python training scripts (e.g., `subscription.py`). By reading from `processed_datasets/`, these scripts avoid re-implementing complex cleaning logic, ensuring that the model is trained on the exact same data distributions explored in the notebooks.

**Sources:**

- [backend/ipynb files/churn_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb)
- [backend/ipynb files/customer_segementation.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/customer_segementation.ipynb)
- [backend/ipynb files/Purchase_Propensity_Modeling.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/Purchase_Propensity_Modeling.ipynb)
- [backend/ipynb files/product.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/product.ipynb)
- [backend/processed_datasets/subscription_renewal_data.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/subscription_renewal_data.csv)
- [backend/processed_datasets/Mall_Customers.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Mall_Customers.csv)
- [backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/Customer_Attributes_and_Purchase_Propensity_processed.csv)