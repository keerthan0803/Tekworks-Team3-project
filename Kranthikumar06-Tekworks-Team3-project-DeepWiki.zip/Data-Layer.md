# Data Layer
Relevant source files
- [README.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1)
- [backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv)
- [backend/raw_datasets/Telco_customer_churn.xlsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Telco_customer_churn.xlsx)
- [backend/raw_datasets/subscription_dataset.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/subscription_dataset.csv)
- [backend/requirements.txt](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt)
- [document.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1)

The **Data Layer** represents the foundational stage of the machine learning lifecycle in the Tekworks project. It encompasses the transition of raw, unstructured, or semi-structured business data into refined, model-ready features. The architecture follows a strict directory convention to ensure reproducibility and clear separation of concerns between raw ingestion and processed outputs.

## Data Lifecycle Overview

The pipeline operates in a two-stage lifecycle managed through Jupyter notebooks and Python training scripts. This ensures that EDA (Exploratory Data Analysis) and feature engineering are documented before being codified into the inference services.

### 1. Ingestion Stage

Raw data is stored in `backend/raw_datasets/`. These files serve as the immutable source of truth for all models. The project supports various formats including `.csv` and `.xlsx`[backend/requirements.txt1-9](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L9)

### 2. Transformation Stage

Jupyter notebooks located in `backend/ipynb files/` perform the ETL (Extract, Transform, Load) operations. These notebooks handle:

- **Null Handling:** Cleaning missing values.
- **Feature Engineering:** Dropping non-predictive columns (e.g., `customerID`) and binning continuous variables.
- **Encoding:** Converting categorical strings into numeric formats using `LabelEncoder` or `get_dummies`.
- **Serialization:** Saving the refined data to `backend/processed_datasets/` for use by training scripts [document.md32-35](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L32-L35)

## Data Flow Architecture

The following diagram illustrates how data flows from raw files through the transformation environment into the training and inference layers.

**System Data Flow: Raw to Inference**

```mermaid
flowchart TD
    subgraph subGraph4 ["Serialized Artifacts"]
        F["backend/models/*.pkl"]
        G["backend/models/*.joblib"]
    end
    subgraph subGraph3 ["Model Training"]
        E["backend/py_files/*.py (Training)"]
    end
    subgraph subGraph2 ["Refined Storage"]
        D["backend/processed_datasets/*.csv"]
    end
    subgraph subGraph1 ["Transformation (Notebooks)"]
        C["backend/ipynb files/*.ipynb"]
    end
    subgraph subGraph0 ["Raw Storage"]
        A["backend/raw_datasets/*.csv"]
        B["backend/raw_datasets/*.xlsx"]
    end
    A --> C
    B --> C
    C --> D
    D --> E
    E --> F
    E --> G
```

Sources: [document.md22-35](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L22-L35)[README.md36-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L36-L44)

## Directory Conventions

| Directory | Role | Format |
| --- | --- | --- |
| `backend/raw_datasets/` | Primary source data for training and testing. | `.csv`, `.xlsx` |
| `backend/ipynb files/` | EDA and transformation logic. | `.ipynb` |
| `backend/processed_datasets/` | Model-ready data after cleaning and encoding. | `.csv` |
| `backend/models/` | Serialized model objects, scalers, and encoders. | `.pkl`, `.joblib` |

## Model-to-Data Mapping

Each predictive service is backed by specific datasets. The transformations applied to these datasets must be mirrored in the `prepare_input` functions within the `backend/py_files/` service modules to ensure consistency between training and inference.

**Entity Relationship: Datasets to Code Entities**

```mermaid
flowchart TD
    subgraph subGraph1 ["Code Entities (Training & Inference)"]
        S1["churn.py / churn_service.py"]
        S2["subscription.py / subscription_service.py"]
        S3["market_responce.py / market_response_service.py"]
        S4["product_demand.py / product_demand_service.py"]
    end
    subgraph subGraph0 ["Data Entities"]
        D1["Telco_customer_churn.xlsx"]
        D2["WA_Fn-UseC_-Telco-Customer-Churn.csv"]
        D3["campaign_responses.csv"]
        D4["Time_Series_Forcasting.csv"]
    end
    D1 --> S1
    D2 --> S2
    D3 --> S3
    D4 --> S4
```

Sources: [README.md38-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L38-L44)[document.md42-64](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L42-L64)

---

## Child Pages

For detailed documentation on specific datasets and transformation logic, refer to the following sub-pages:

- **[Raw Datasets](/Kranthikumar06/Tekworks-Team3-project/5.1-raw-datasets)**
Detailed breakdown of the eight raw dataset files, including column definitions for churn, subscription, market response, and product demand.
- **[Processed Datasets & Jupyter Notebooks](/Kranthikumar06/Tekworks-Team3-project/5.2-processed-datasets-and-jupyter-notebooks)**
Technical documentation of the ETL pipeline, categorical encoding strategies (Manual vs. One-Hot), and the role of processed CSVs as the bridge to the training scripts.