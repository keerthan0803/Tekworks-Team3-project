# Inference Service Pattern
Relevant source files
- [backend/py_files/churn_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py)
- [backend/py_files/customer_segmentation_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py)
- [backend/py_files/market_response_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py)
- [backend/py_files/purchase_propensity_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py)
- [backend/py_files/subscription_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py)

The Tekworks backend utilizes a standardized design pattern across all seven predictive service modules located in `backend/py_files/`. This pattern ensures consistency in how model artifacts are loaded, how input data is validated via Pydantic, and how raw JSON payloads are transformed into model-ready DataFrames.

## Architectural Overview

Each service module follows a "fail-fast" initialization strategy where ML artifacts (models, scalers, and encoders) are loaded at the module level. This ensures that the FastAPI server will not start or will immediately error out if the required dependencies for inference are missing.

### Inference Data Flow

The following diagram illustrates the standard data flow from the REST endpoint to the prediction result.

**Standard Inference Lifecycle**

```mermaid
flowchart TD
    subgraph subGraph3 ["Artifact Store"]
        K[".pkl / .joblib files"]
    end
    subgraph subGraph2 ["Service Module (e.g., churn_service.py)"]
        C["predict_function()"]
        H["Scaling (StandardScaler)"]
        I["Model.predict() / predict_proba()"]
        J["JSON Response Construction"]
        subgraph Preprocessing
            D["prepare_input()"]
            E["pd.DataFrame Conversion"]
            F["Categorical Encoding (Label/One-Hot)"]
            G["Column Reindexing & Alignment"]
        end
    end
    subgraph subGraph0 ["FastAPI Layer (app.py)"]
        A["POST /predict/*"]
        B["PredictRequest (Pydantic)"]
    end
    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
    F --> G
    G --> H
    H --> I
    I --> J
    K -.->|"Loaded at Startup"| I
    K -.->|"Loaded at Startup"| H
    K -.->|"Loaded at Startup"| F
```

**Sources:**[backend/py_files/purchase_propensity_service.py15-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L15-L34)[backend/py_files/churn_service.py18-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L18-L44)[backend/py_files/subscription_service.py19-50](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L19-L50)

---

## 1. Module Initialization & Artifact Loading

Services use either `pickle` or `joblib` to deserialize artifacts. Most services load three distinct components:

1. **The Model:** The trained estimator (e.g., `AdaBoostClassifier`, `LogisticRegression`).
2. **The Scaler:** A `StandardScaler` fitted on training data to normalize numerical inputs.
3. **The Encoders:**`LabelEncoder` objects or mappings for categorical features.

If any artifact is missing from the `backend/models/` directory, the module raises a `RuntimeError`, preventing invalid service states.

| Service | Serialization Tool | Key Artifacts |
| --- | --- | --- |
| `purchase_propensity_service.py` | `joblib` | `purchase_propensity_model.pkl`, `_scaler.pkl`, `_encoders.pkl` |
| `churn_service.py` | `pickle` | `churn_model_ada.pkl` |
| `subscription_service.py` | `pickle` | `subscription_renewal_model.pkl` |
| `customer_segmentation_service.py` | `joblib` | `customer_segmentation_kmeans.pkl`, `_scaler.pkl`, `_gender_encoder.pkl` |

**Sources:**[backend/py_files/purchase_propensity_service.py26-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L26-L34)[backend/py_files/customer_segmentation_service.py21-29](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L21-L29)[backend/py_files/churn_service.py22-27](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L22-L27)

---

## 2. Request Validation (Pydantic Models)

Most services define a `PredictRequest` class that expects a nested `data` dictionary. This structure allows the frontend to pass arbitrary key-value pairs that are then converted into a single-row DataFrame.

```
class PredictRequest(BaseModel):
    data: Dict[str, Any]
```

**Exception:** The `market_response_service.py` uses a flat schema where every feature is explicitly typed in the `MarketResponseRequest` class.

**Sources:**[backend/py_files/purchase_propensity_service.py11-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L11-L12)[backend/py_files/market_response_service.py25-32](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L25-L32)

---

## 3. Input Preprocessing (`prepare_input`)

The `prepare_input` function is responsible for bridging the gap between raw JSON and the exact feature vector expected by the model.

### Key Operations:

1. **DataFrame Conversion:** Wraps the input dictionary in a list to create a single-row `pandas.DataFrame`[backend/py_files/purchase_propensity_service.py48](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L48-L48)
2. **Categorical Encoding:**
- **Label Encoding:** Iterates through saved encoders and applies `transform()` to specific columns [backend/py_files/purchase_propensity_service.py50-59](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L50-L59)
- **One-Hot Encoding:** Uses `pd.get_dummies()` for models like Churn that require expanded feature sets [backend/py_files/churn_service.py53](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L53-L53)
3. **Column Alignment:** Uses `.reindex(columns=expected_columns, fill_value=0)` to ensure the input features match the training set exactly, adding missing columns (common in one-hot encoding) and removing extraneous ones [backend/py_files/purchase_propensity_service.py61](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L61-L61)

**Sources:**[backend/py_files/purchase_propensity_service.py47-61](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L47-L61)[backend/py_files/churn_service.py47-54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L47-L54)[backend/py_files/subscription_service.py53-74](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L53-L74)

---

## 4. Prediction Logic & Response Mapping

The main entry point (e.g., `predict_purchase_propensity`) orchestrates the call to the model and formats the output for JSON serialization.

### Probability Extraction

If the model supports `predict_proba`, the service extracts the probability of the positive class (index 1) to provide a confidence score to the UI.

```
if hasattr(purchase_model, "predict_proba"):
    proba = purchase_model.predict_proba(scaled_input)[0]
    response["probability"] = float(proba[1])
```

### Result Mapping

Numeric predictions (0 or 1) are mapped to human-readable strings like "Purchased" or "Not Purchased" before being returned.

**Code Entity Relationship Diagram**

```mermaid
classDiagram
    class PredictRequest {
        +dict data
    }
    class ServiceModule {
        +expected_columns list
        +prepare_input(data) : pd.DataFrame
        +predict_function(request) : dict
        +load_bundle() : dict
    }
    class Artifacts {
        +model
        +scaler
        +encoders
    }
    ServiceModule ..> PredictRequest : consumes
    ServiceModule ..> Artifacts : uses
```

**Sources:**[backend/py_files/purchase_propensity_service.py64-101](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L64-L101)[backend/py_files/churn_service.py60-84](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L60-L84)[backend/py_files/customer_segmentation_service.py69-103](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L69-L103)

---

## 5. Specialized Implementations

While most services follow the standard pattern, two modules include additional logic:

- **Customer Segmentation:** Includes a `compute_tsne_point` function that uses `sklearn.manifold.TSNE` to project the high-dimensional input into 2D coordinates (`tsne_x`, `tsne_y`) for frontend visualization [backend/py_files/customer_segmentation_service.py56-66](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L56-L66)
- **Market Response:** Uses a manual `encode_market_value` helper to handle individual feature transformations instead of a bulk DataFrame approach [backend/py_files/market_response_service.py35-48](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L35-L48)

**Sources:**[backend/py_files/customer_segmentation_service.py89-102](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L89-L102)[backend/py_files/market_response_service.py50-68](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/market_response_service.py#L50-L68)