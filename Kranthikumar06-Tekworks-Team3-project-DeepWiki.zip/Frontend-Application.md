# Frontend Application
Relevant source files
- [frontend/index.html](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/index.html)
- [frontend/src/App.tsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx)
- [frontend/src/index.css](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css)
- [frontend/src/main.tsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/main.tsx)

The frontend of the Tekworks Team3 project, branded as **Intellix Premium UI**, is a high-performance Single-Page Application (SPA) built with **Vite** and **React**. It serves as a unified intelligence workspace, providing a sophisticated interface for interacting with seven distinct machine learning models hosted on the FastAPI backend.

### Architecture Overview

The application follows a modular, configuration-driven architecture. Instead of hard-coding separate pages for each model, the UI utilizes a centralized registry of view configurations (`ViewConfig`) that dynamically generates forms, validation logic, and result visualizations [frontend/src/App.tsx102-114](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L102-L114)

#### System-to-Code Entity Mapping

The following diagram bridges the functional workspace names to their implementation entities within the React application.

**Workspace to Code Entity Bridge**

```mermaid
flowchart LR
    subgraph subGraph1 ["Code Entity Space (frontend/src/App.tsx)"]
        V1["view.id: 'churn'"]
        V2["view.id: 'subscription'"]
        V3["view.id: 'market'"]
        V4["view.id: 'product'"]
        V5["view.id: 'sensitivity'"]
        V6["view.id: 'propensity'"]
        V7["view.id: 'segmentation'"]
        VIEWS["const views = useMemo(...)"]
        FSTATE["const #91;formState, setFormState#93;"]
    end
    subgraph subGraph0 ["Natural Language Space"]
        W1["Churn Prediction"]
        W2["Subscription Renewal"]
        W3["Market Response"]
        W4["Product Demand"]
        W5["Price Sensitivity"]
        W6["Purchase Propensity"]
        W7["Customer Segmentation"]
    end
    W1 --> V1
    W2 --> V2
    W3 --> V3
    W4 --> V4
    W5 --> V5
    W6 --> V6
    W7 --> V7
    V1 --> VIEWS
    V2 --> VIEWS
    V3 --> VIEWS
    V4 --> VIEWS
    V5 --> VIEWS
    V6 --> VIEWS
    V7 --> VIEWS
    VIEWS --> FSTATE
```

**Sources:**[frontend/src/App.tsx102-450](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L102-L450)[frontend/src/App.tsx505-515](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L505-L515)

### Core Components & Layout

The UI is structured around a persistent sidebar navigation and a dynamic main workspace area. This layout ensures that users can quickly pivot between different analytical models while maintaining the context of their current work.

| Component Area | Responsibility | Key Code Symbols |
| --- | --- | --- |
| **Sidebar** | Navigation between model workspaces and "About" section. | `.sidebar`, `.nav-item` |
| **Workspace Header** | Displays model title, description, and export actions. | `.workspace-header`, `handleExport` |
| **Parameters Form** | Dynamic input generation based on model requirements. | `.parameters-form`, `FieldGroup` |
| **Output Pane** | Visualizes predictions, probabilities, and cluster data. | `.prediction-output-pane`, `RadarScanner` |

**Component Communication Flow**

```mermaid
flowchart LR
    subgraph External
        API["FastAPI Backend"]
        PRINT["Browser Print (PDF)"]
    end
    subgraph subGraph1 ["Logic Layer (App.tsx)"]
        VCONFIG["ViewConfig Registry"]
        H_SUBMIT["handleSubmit()"]
        H_EXPORT["handleExport()"]
    end
    subgraph subGraph0 ["UI Layer"]
        NAV["Sidebar Navigation"]
        FORM["Parameters Form"]
        OUT["Output Pane"]
    end
    NAV -->|"Sets activeView"| VCONFIG
    VCONFIG -->|"Renders Fields"| FORM
    FORM -->|"Trigger Inference"| H_SUBMIT
    H_SUBMIT -->|"POST /predict/*"| API
    API -->|"JSON Response"| H_SUBMIT
    H_SUBMIT -->|"Update resultsState"| OUT
    OUT -->|"Trigger Export"| H_EXPORT
    H_EXPORT --> PRINT
```

**Sources:**[frontend/src/App.tsx460-480](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L460-L480)[frontend/src/App.tsx530-580](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L530-L580)[frontend/src/App.tsx640-700](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L640-L700)

---

### [App Component & Inference Workflow](/Kranthikumar06/Tekworks-Team3-project/4.1-app-component-and-inference-workflow)

The `App.tsx` file serves as the central controller for the entire frontend. It manages the state for all seven workspaces simultaneously using a `formState` object keyed by model ID. It handles the complex lifecycle of an inference request: serializing form data, casting types (e.g., converting strings to numbers for the ML models), and transforming categorical seasons into numeric maps before dispatching to the FastAPI backend.

For details, see [App Component & Inference Workflow](/Kranthikumar06/Tekworks-Team3-project/4.1-app-component-and-inference-workflow).

**Sources:**[frontend/src/App.tsx505-520](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L505-L520)[frontend/src/App.tsx534-590](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L534-L590)

### [UI Design System & Styling](/Kranthikumar06/Tekworks-Team3-project/4.2-ui-design-system-and-styling)

The application utilizes a custom design system defined in `index.css` and `App.css`. It features a "Premium" aesthetic using the **Inter** typeface, a refined color palette of deep blues and slate grays, and sophisticated UI elements like the `ProbabilityMeter` and `RadarScanner`. The styling includes specific `@media print` rules to ensure that exported reports are formatted professionally.

For details, see [UI Design System & Styling](/Kranthikumar06/Tekworks-Team3-project/4.2-ui-design-system-and-styling).

**Sources:**[frontend/src/index.css1-30](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L1-L30)[frontend/index.html11-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/index.html#L11-L12)

### [Frontend Tooling & Configuration](/Kranthikumar06/Tekworks-Team3-project/4.3-frontend-tooling-and-configuration)

The development and build environment is powered by **Vite**. The configuration ensures fast Hot Module Replacement (HMR) during development and optimized asset bundling for production. The project is strictly typed with **TypeScript**, utilizing specialized configurations for the application logic and the build tooling.

For details, see [Frontend Tooling & Configuration](/Kranthikumar06/Tekworks-Team3-project/4.3-frontend-tooling-and-configuration).

**Sources:**[frontend/index.html15](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/index.html#L15-L15)[frontend/src/main.tsx1-10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/main.tsx#L1-L10)