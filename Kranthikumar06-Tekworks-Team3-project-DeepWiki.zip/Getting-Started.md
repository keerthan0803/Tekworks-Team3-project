# Getting Started
Relevant source files
- [README.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1)
- [backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv)
- [backend/raw_datasets/Telco_customer_churn.xlsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Telco_customer_churn.xlsx)
- [backend/raw_datasets/subscription_dataset.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/subscription_dataset.csv)
- [backend/requirements.txt](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt)
- [document.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1)
- [frontend/package.json](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json)
- [frontend/vite.config.ts](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/vite.config.ts)

This page provides a step-by-step technical guide for setting up the Tekworks Team3 ML platform locally. The system comprises a **FastAPI** backend serving seven machine learning models and a **Vite + React** frontend for interactive inference [README.md1-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L1-L12)

## System Requirements

The project requires the following environments:

- **Python 3.8+**: For the FastAPI backend and ML inference services.
- **Node.js (LTS)**: For the Vite-powered React frontend.
- **Git LFS**: Essential for pulling the serialized model artifacts (`.pkl` and `.joblib`) stored in `backend/models/`.

## Backend Setup

The backend acts as the central hub, managing data preprocessing and model execution. It utilizes `uvicorn` as the ASGI server to handle asynchronous requests [backend/requirements.txt11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L11-L11)

### 1. Dependency Installation

Navigate to the root directory and install the required Python packages. These include core ML libraries like `scikit-learn`, `pandas`, and `numpy`, as well as web utilities like `fastapi`[backend/requirements.txt1-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L7)

```
pip install -r backend/requirements.txt
```

### 2. Launching the API

The entry point for the backend is `app.py`. Run the server using `uvicorn` with the `--reload` flag for development [README.md16-21](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L16-L21)

```
cd backend
uvicorn app:app --reload
```

By default, the API will be available at `http://127.0.0.1:8000`[README.md47](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L47-L47)

### 3. Model Artifact Verification

The system expects pre-trained models to exist in `backend/models/`. If these files are missing or need to be regenerated from the raw datasets in `backend/raw_datasets/`, execute the corresponding training scripts located in `backend/py_files/`[document.md22-84](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L22-L84)

**Sources:**[README.md16-21](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L16-L21)[backend/requirements.txt1-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt#L1-L11)[document.md10-21](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L10-L21)[document.md84](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L84-L84)

## Frontend Setup

The frontend is a modern React application built with Vite. It provides a unified interface to interact with all seven predictive models [document.md4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L4-L4)

### 1. Dependency Installation

Navigate to the `frontend` directory and install the Node dependencies defined in `package.json`[frontend/package.json12-28](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L12-L28)

```
cd frontend
npm install
```

### 2. Environment Configuration

The frontend communicates with the backend via a base URL. If your backend is running on a non-default port or host, configure the `VITE_API_BASE_URL` environment variable [README.md30-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L30-L34)

```
# Example for local development
VITE_API_BASE_URL=http://127.0.0.1:8000
```

### 3. Running the Development Server

Start the Vite development server to launch the "Intellix Premium UI" [frontend/package.json7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L7-L7)

```
npm run dev
```

**Sources:**[README.md23-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L23-L34)[document.md65-81](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L65-L81)[frontend/package.json1-30](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L1-L30)

## System Initialization Flow

The following diagram illustrates the sequence of operations required to bring the full-stack system online, mapping setup steps to specific code entities.

### Setup Sequence Diagram

```mermaid
sequenceDiagram
    participant User
    participant FS as "File System"
    participant BE as "FastAPI (app.py)"
    participant FE as "Vite (App.tsx)"
    User->>FS: pip install -r backend/requirements.txt
    User->>FS: npm install (frontend/)
    Note over User,FS: Ensure backend/models/*.pkl exist
    User->>BE: uvicorn app:app --reload
    BE->>BE: Load ML Services (py_files/)
    BE-->>User: API Live at port 8000
    User->>FE: VITE_API_BASE_URL=http://... npm run dev
    FE->>FE: Vite Build/HMR
    FE-->>User: UI Live at port 5173
```

**Sources:**[README.md14-28](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L14-L28)[document.md10-20](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L10-L20)[document.md66-75](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L66-L75)

## Data and Service Connectivity

The system relies on a strict directory structure and environment variables to connect the frontend UI components to the backend inference logic.

### Entity Relationship Diagram

```

```

### Configuration Summary

| Variable | Default Value | Description |
| --- | --- | --- |
| `VITE_API_BASE_URL` | `http://127.0.0.1:8000` | The endpoint where the FastAPI `app` instance is listening [README.md33-47](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L33-L47) |
| `PORT` (Backend) | `8000` | Managed by `uvicorn`[README.md20](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L20-L20) |
| `Scripts` (Frontend) | `dev`, `build`, `lint` | Standard Vite/TS workflow commands [frontend/package.json6-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L6-L11) |

**Sources:**[README.md30-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L30-L34)[document.md77-81](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L77-L81)[frontend/package.json6-11](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/package.json#L6-L11)[frontend/vite.config.ts1-7](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/vite.config.ts#L1-L7)