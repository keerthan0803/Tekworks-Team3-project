# Git LFS & Binary File Management
Relevant source files
- [.gitattributes](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitattributes)
- [backend/models/churn_model_ada.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl)

This page details the implementation and configuration of **Git Large File Storage (LFS)** within the Tekworks Team3 project. Because the machine learning lifecycle produces serialized binary artifacts (models, scalers, and encoders) that can be large and frequently updated, Git LFS is utilized to prevent repository bloat and ensure efficient version control.

## Purpose of Git LFS in ML Workflows

Standard Git is not optimized for binary files. Every time a `.pkl` or `.joblib` file is modified and committed, Git stores the entire new version in the history, leading to an exponential increase in the `.git` folder size. In this project, Git LFS addresses this by:

1. **Decoupling Blobs from History**: Large files are stored in a separate remote store, while the repository only tracks lightweight "pointer files."
2. **Efficient Cloning**: Users only download the specific versions of the models needed for the current checkout, rather than the entire history of every binary artifact.
3. **Integrity**: Uses SHA-256 hashing to ensure that the binary file downloaded matches the version expected by the code.

## Configuration and Tracking

The project uses a `.gitattributes` file located at the repository root to define which file extensions should be handled by the LFS filter.

### LFS Filter Rules

The configuration explicitly targets Python serialization formats used across all seven predictive models:

| Extension | Filter | Diff | Merge | Text Handling |
| --- | --- | --- | --- | --- |
| `*.pkl` | `lfs` | `lfs` | `lfs` | `-text` (Binary) |

Sources: [.gitattributes1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitattributes#L1-L1)

## The Pointer File Format

When viewing the repository without the LFS client installed, or when looking at the raw Git object, a "pointer file" is visible instead of the actual binary data. These files are approximately 100-200 bytes and follow a specific schema.

### Anatomy of a Pointer File

Taking `backend/models/churn_model_ada.pkl` as an example:

```
version https://git-lfs.github.com/spec/v1
oid sha256:24ceb14e40f60a9652520a897ba6467a33bf41597e1686952f868567b9785f61
size 55931
```

- **version**: Defines the LFS spec version [backend/models/churn_model_ada.pkl1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L1)
- **oid sha256**: The unique Content Addressable Storage (CAS) identifier for the binary blob [backend/models/churn_model_ada.pkl2](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L2-L2)
- **size**: The actual size of the binary file in bytes (e.g., ~55 KB for the Churn AdaBoost model) [backend/models/churn_model_ada.pkl3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L3-L3)

Sources: [backend/models/churn_model_ada.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L3)

## Data Flow: From Remote to Runtime

The following diagram illustrates how Git LFS mediates the transition from the remote repository to the local filesystem where the FastAPI backend loads the artifacts.

### LFS Resolution Workflow

"Natural Language Space" (User/Server) to "Code Entity Space" (LFS/Backend)

```

```

Sources: [.gitattributes1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitattributes#L1-L1)[backend/models/churn_model_ada.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L3)

## Implementation in Model Services

The backend services assume that Git LFS has successfully "hydrated" the pointer files into actual binaries. If LFS is not configured correctly on a developer's machine, the Python `pickle` or `joblib` loaders will attempt to read the text-based pointer file and fail with a `UnpicklingError`.

### Artifact Loading Pattern

The services utilize the hydrated files located in `backend/models/`. The following diagram maps the logical models to their LFS-tracked physical entities.

### Model-to-Artifact Mapping

```

```

Sources: [.gitattributes1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitattributes#L1-L1)[backend/models/churn_model_ada.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L3)

## Operational Guide

### Pulling LFS Objects

If the files in `backend/models/` appear as small text files containing `version https://git-lfs...`, the LFS objects have not been pulled. Run the following commands:

1. **Install LFS Extension**: `git lfs install`
2. **Pull Binaries**: `git lfs pull`

### Adding New Models

When adding a new model (e.g., `new_model.joblib`), ensure it is tracked by LFS:

1. Verify the extension is in `.gitattributes`[.gitattributes1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitattributes#L1-L1)
2. Add the file: `git add backend/models/new_model.joblib`.
3. Commit: `git commit -m "Add new model artifact"`.
4. Git will automatically convert the file to a pointer before pushing.

Sources: [.gitattributes1](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitattributes#L1-L1)[backend/models/churn_model_ada.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L3)