# Model Artifacts & Versioning
Relevant source files
- [.gitattributes](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitattributes)
- [backend/models/churn_model_ada.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl)
- [backend/models/customer_segmentation_gender_encoder.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_gender_encoder.pkl)
- [backend/models/customer_segmentation_kmeans.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_kmeans.pkl)
- [backend/models/customer_segmentation_scaler.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_scaler.pkl)
- [backend/models/market_response_encoders.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_encoders.pkl)
- [backend/models/market_response_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_model.pkl)
- [backend/models/market_response_scaler.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_scaler.pkl)
- [backend/models/product_demand_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_demand_model.pkl)
- [backend/models/product_demand_scaler.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_demand_scaler.pkl)
- [backend/models/product_sensitivity_dt_model.joblib](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_dt_model.joblib)
- [backend/models/product_sensitivity_label_encoders.joblib](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_label_encoders.joblib)
- [backend/models/purchase_propensity_encoders.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_encoders.pkl)
- [backend/models/purchase_propensity_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_model.pkl)
- [backend/models/purchase_propensity_scaler.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/purchase_propensity_scaler.pkl)
- [backend/models/subscription_renewal_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/subscription_renewal_model.pkl)

The `backend/models/` directory serves as the centralized repository for all serialized machine learning artifacts required for production inference. The system currently manages **15 distinct artifacts** across seven predictive models. These artifacts are generated during the offline training phase and are loaded into memory by the FastAPI service modules at application startup to ensure low-latency predictions.

### Serialization Strategy

The project utilizes two primary Python libraries for object serialization, chosen based on the specific requirements of the model algorithms and data structures:

| Library | Usage | Reason |
| --- | --- | --- |
| **Pickle** (`.pkl`) | Default for most models, scalers, and label encoders. | Standard Python serialization for Scikit-Learn objects. |
| **Joblib** (`.joblib`) | Used specifically for the Product Sensitivity (Dynamic Pricing) model. | Optimized for objects containing large numerical arrays (e.g., complex Decision Trees). |

### Fail-Fast Loading Behavior

To maintain system integrity, the inference services implemented in `backend/py_files/` follow a "fail-fast" initialization pattern. When the backend starts, each service attempts to locate and load its required artifacts from `backend/models/`. If any file is missing or corrupted, the system raises a `RuntimeError`, preventing the API from serving incomplete or broken models.

**Sources:**

- [backend/models/product_sensitivity_dt_model.joblib1-8](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_dt_model.joblib#L1-L8) (Binary joblib structure)
- [backend/models/churn_model_ada.pkl1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L4) (Pickle pointer)

---

### Artifact Relationship Mapping

Most predictive models in the platform follow a **Three-Artifact Pattern**, consisting of the trained estimator, a numerical scaler, and categorical encoders. The diagram below illustrates how these artifacts bridge the gap between the raw input data and the code entities in the inference layer.

**Model Artifact Integration Diagram**

```mermaid
flowchart LR
    subgraph subGraph2 ["Artifact Space (backend/models/)"]
        Model["model.pkl (Estimator)"]
        Scaler["scaler.pkl (StandardScaler)"]
        Encoder["encoders.pkl (LabelEncoders)"]
    end
    subgraph subGraph1 ["Code Entity Space (backend/py_files/)"]
        Service["Inference Service (e.g., market_response_service.py)"]
        Load["Artifact Loading (pickle.load)"]
    end
    subgraph subGraph0 ["Natural Language Space"]
        Input["User Input (Form Data)"]
        Pred["Prediction Result"]
    end
    Input --> Service
    Service --> Load
    Load -.-> Model
    Load -.-> Scaler
    Load -.-> Encoder
    Service -->|"1. Preprocess"| Encoder
    Service -->|"2. Scale"| Scaler
    Service -->|"3. Predict"| Model
    Model --> Pred
```

**Sources:**

- [backend/models/market_response_model.pkl1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_model.pkl#L1-L4)
- [backend/models/market_response_scaler.pkl1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_scaler.pkl#L1-L4)
- [backend/models/market_response_encoders.pkl1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/market_response_encoders.pkl#L1-L4)

---

### Artifact Inventory

The platform hosts a diverse set of artifacts ranging from simple Logistic Regression weights to complex AdaBoost and KMeans models. For a complete list of all 15 files, their associated algorithms, and the training scripts that produce them, see the [Artifact Inventory](/Kranthikumar06/Tekworks-Team3-project/6.1-artifact-inventory) child page.

**Summary of Key Artifacts:**

- **Churn Prediction**: `churn_model_ada.pkl` (AdaBoost)
- **Market Response**: `market_response_model.pkl`, `scaler.pkl`, `encoders.pkl`
- **Dynamic Pricing**: `product_sensitivity_dt_model.joblib`, `label_encoders.joblib`
- **Segmentation**: `customer_segmentation_kmeans.pkl`, `scaler.pkl`, `gender_encoder.pkl`

**Sources:**

- [backend/models/customer_segmentation_kmeans.pkl1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/customer_segmentation_kmeans.pkl#L1-L4)
- [backend/models/product_sensitivity_dt_model.joblib1-5](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/product_sensitivity_dt_model.joblib#L1-L5)

---

### Git LFS & Binary Management

Because serialized models are binary files that can grow significantly in size, the repository uses **Git Large File Storage (LFS)**. This ensures that the main Git history remains lightweight by replacing large binary blobs with text-based pointer files.

**Pointer File Structure Example:**

```
version https://git-lfs.github.com/spec/v1
oid sha256:24ceb14e40f60a9652520a897ba6467a33bf41597e1686952f868567b9785f61
size 55931
```

For instructions on how to configure LFS, track new `.pkl` files, and ensure artifacts are correctly downloaded during a `git clone`, see [Git LFS & Binary File Management](/Kranthikumar06/Tekworks-Team3-project/6.2-git-lfs-and-binary-file-management).

**Sources:**

- [.gitattributes1-2](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/.gitattributes#L1-L2) (LFS tracking configuration)
- [backend/models/churn_model_ada.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L3) (LFS pointer format)

---

### Child Pages

- [Artifact Inventory](/Kranthikumar06/Tekworks-Team3-project/6.1-artifact-inventory) — Detailed technical specifications for every `.pkl` and `.joblib` file.
- [Git LFS & Binary File Management](/Kranthikumar06/Tekworks-Team3-project/6.2-git-lfs-and-binary-file-management) — Workflow and configuration for handling large model files in Git.