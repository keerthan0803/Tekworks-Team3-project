# Subscription Renewal Model
Relevant source files
- [backend/ipynb files/subscription_renewal_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/subscription_renewal_prediction.ipynb)
- [backend/models/subscription_renewal_model.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/subscription_renewal_model.pkl)
- [backend/processed_datasets/subscription_renewal_data.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/subscription_renewal_data.csv)
- [backend/py_files/subscription.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py)
- [backend/py_files/subscription_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py)
- [backend/raw_datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv)
- [backend/raw_datasets/campaign_responses.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/campaign_responses.csv)

The Subscription Renewal Model is a binary classification pipeline designed to predict whether a customer will renew their service subscription. It utilizes customer demographic and service usage data to estimate the likelihood of churn versus renewal, providing actionable insights for retention strategies.

## Pipeline Overview

The pipeline transitions from raw data ingestion to a trained Logistic Regression model, which is then served via a FastAPI service for real-time inference.

### Data Flow

The following diagram illustrates the transition from the "Natural Language Space" (customer attributes) to the "Code Entity Space" (processed tensors and model artifacts).

**Subscription Data Transformation Flow**

```mermaid
flowchart TD
    subgraph subGraph2 ["Code Entity Space: Inference (subscription_service.py)"]
        F["PredictRequest.data"]
        G["prepare_input()"]
        H["load_bundle()"]
        I["predict_subscription()"]
        J["JSON Response: 'Renew' / 'Not Renew'"]
    end
    subgraph subGraph1 ["Code Entity Space: Training (subscription.py)"]
        C["encode_categorical()"]
        D["LogisticRegression.fit()"]
        E["subscription_renewal_model.pkl"]
    end
    subgraph subGraph0 ["Natural Language Space"]
        A["WA_Fn-UseC_-Telco-Customer-Churn.csv"]
        B["Raw Features: tenure, Contract, MonthlyCharges, etc."]
    end
    A --> B
    B --> C
    C --> D
    D --> E
    F --> G
    E --> H
    G --> I
    H --> I
    I --> J
```

Sources: [backend/py_files/subscription.py40-60](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py#L40-L60)[backend/py_files/subscription_service.py12-14](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L12-L14)[backend/py_files/subscription_service.py53-74](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L53-L74)[backend/py_files/subscription_service.py80-109](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L80-L109)

## Training Pipeline

The training process is encapsulated in `subscription.py` and documented in the `subscription_renewal_prediction.ipynb` notebook.

### Feature Selection

The model focuses on a subset of the Telco dataset identified as high-impact predictors for renewal:

- **Numerical**: `tenure`, `MonthlyCharges`.
- **Categorical**: `Contract`, `PaymentMethod`, `InternetService`, `TechSupport`.

### Implementation Details

1. **Loading**: The script loads data from `subscription_renewal_data.csv`[backend/py_files/subscription.py22-25](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py#L22-L25)
2. **Encoding**: Categorical variables are converted to numerical labels using `LabelEncoder` within the `encode_categorical` function [backend/py_files/subscription.py40-60](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py#L40-L60)
3. **Training**: A `LogisticRegression` model is initialized with `random_state=42` and fitted on an 80/20 train-test split [backend/py_files/subscription.py96-113](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py#L96-L113)
4. **Serialization**: The resulting model is serialized into a `.pkl` file using the `pickle` library [backend/py_files/subscription.py151-154](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py#L151-L154)

Sources: [backend/py_files/subscription.py1-171](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py#L1-L171)[backend/processed_datasets/subscription_renewal_data.csv1-15](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/subscription_renewal_data.csv#L1-L15)

## Inference Service

The `subscription_service.py` module handles the operationalization of the trained model.

### Artifact Loading

Upon module initialization, the `load_bundle()` function performs a "fail-fast" check for the model artifact and the reference training data [backend/py_files/subscription_service.py19-33](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L19-L33) It dynamically recreates the `LabelEncoder` states by fitting them against the unique values found in the `subscription_renewal_data.csv` to ensure encoding consistency between training and inference [backend/py_files/subscription_service.py38-43](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L38-L43)

### Inference Logic

The service follows a structured request-response cycle:

| Step | Entity | Description |
| --- | --- | --- |
| **Input** | `PredictRequest` | Validates the incoming JSON payload containing customer data [backend/py_files/subscription_service.py12-14](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L12-L14) |
| **Preprocessing** | `prepare_input()` | Converts input dict to DataFrame, applies saved `LabelEncoder` transforms, and reindexes to `expected_columns`[backend/py_files/subscription_service.py53-74](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L53-L74) |
| **Prediction** | `predict_subscription()` | Executes `model.predict()` and `model.predict_proba()`[backend/py_files/subscription_service.py91-107](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L91-L107) |
| **Formatting** | `response` | Maps numeric 1 to "Renew" and 0 to "Not Renew" [backend/py_files/subscription_service.py96-97](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L96-L97) |

**Service Interaction Diagram**

```mermaid
sequenceDiagram
    participant API as App.py Endpoint
    participant SVC as subscription_service.py
    participant MDL as subscription_renewal_model.pkl
    API->>SVC: predict_subscription(PredictRequest)
    SVC->>SVC: prepare_input(data)
    SVC->>MDL: model.predict(input_df)
    MDL-->>SVC: ndarray([1])
    SVC->>MDL: model.predict_proba(input_df)
    MDL-->>SVC: ndarray([[0.15, 0.85]])
    SVC-->>API: {"prediction": "Renew", "probability": 0.85}
```

Sources: [backend/py_files/subscription_service.py19-50](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L19-L50)[backend/py_files/subscription_service.py80-109](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription_service.py#L80-L109)

## Data Specifications

### Raw Dataset

The source data is `WA_Fn-UseC_-Telco-Customer-Churn.csv`, a standard industry dataset containing 21 columns including `customerID`, `gender`, `tenure`, and the target `Churn`[backend/raw_datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv1-20](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv#L1-L20)

### Model Artifact

The model is stored as a Git LFS tracked file:

- **Path**: `backend/models/subscription_renewal_model.pkl`
- **Format**: Pickle
- **Size**: ~936 bytes (LFS pointer)
- **Algorithm**: Logistic Regression

Sources: [backend/models/subscription_renewal_model.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/subscription_renewal_model.pkl#L1-L3)[backend/py_files/subscription.py111-113](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py#L111-L113)