# Churn Prediction Model
Relevant source files
- [backend/ipynb files/churn_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb)
- [backend/models/churn_model_ada.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl)
- [backend/processed_datasets/churn_prediction_data.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/churn_prediction_data.csv)
- [backend/py_files/churn.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn.py)
- [backend/py_files/churn_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py)
- [backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Customer_Attributes_and_Purchase_Propensity.csv)
- [backend/raw_datasets/Telco_customer_churn.xlsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Telco_customer_churn.xlsx)
- [backend/raw_datasets/subscription_dataset.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/subscription_dataset.csv)
- [backend/requirements.txt](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/requirements.txt)

The Churn Prediction Model is a binary classification system designed to identify customers at risk of leaving the service. It utilizes an AdaBoost ensemble architecture to process customer demographics, service usage patterns, and contract details to output a churn probability and a categorical "Yes/No" prediction.

## Data Lifecycle and Flow

The model transitions from raw spreadsheet data through a preprocessing pipeline to a serialized artifact used for real-time inference.

### 1. Data Ingestion & Preprocessing

The pipeline begins with `Telco_customer_churn.xlsx`[backend/raw_datasets/Telco_customer_churn.xlsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/Telco_customer_churn.xlsx) The initial exploratory data analysis and transformation are performed in the Jupyter notebook `churn_prediction.ipynb`[backend/ipynb files/churn_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb)

Key transformations include:

- **Feature Dropping**: Irrelevant identifiers and high-leakage features such as `CustomerID`, `Count`, `Country`, `State`, `Lat Long`, `Latitude`, `Longitude`, `Churn Score`, `CLTV`, and `Churn Reason` are removed [backend/ipynb files/churn_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb)
- **City Binning**: The `City` column is processed to reduce cardinality [backend/ipynb files/churn_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb)
- **Categorical Encoding**: Variables like `Gender`, `Senior Citizen`, `Partner`, and `Dependents` are converted into numerical formats suitable for machine learning [backend/ipynb files/churn_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb)

The resulting cleaned dataset is saved as `churn_prediction_data.csv`[backend/processed_datasets/churn_prediction_data.csv1-10](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/churn_prediction_data.csv#L1-L10)

### 2. Model Training (`churn.py`)

The training script [backend/py_files/churn.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn.py) implements the following logic:

- **One-Hot Encoding**: It dynamically identifies categorical columns (e.g., `Contract`, `Payment Method`) and applies `pd.get_dummies`[backend/py_files/churn.py13-17](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn.py#L13-L17)
- **Algorithm**: Uses `AdaBoostClassifier` with 100 estimators [backend/py_files/churn.py24](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn.py#L24-L24)
- **Serialization**: The trained model is saved using `pickle` to `churn_model_ada.pkl`[backend/py_files/churn.py28-29](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn.py#L28-L29)

### 3. Inference Service (`churn_service.py`)

The inference layer handles real-time requests by ensuring the input features match the training schema exactly.

**Churn Inference Data Flow**

```mermaid
flowchart LR
    G["JSON Response"]
    subgraph subGraph1 ["Code Entity Space: churn_service.py"]
        B["PredictRequest"]
        C["load_bundle()"]
        D["prepare_input()"]
        E["predict_churn()"]
        F["bundle#91;'model'#93; (AdaBoost)"]
    end
    subgraph subGraph0 ["Natural Language Space"]
        A["User Input (JSON)"]
    end
    A --> B
    B --> E
    C --> F
    E --> D
    D --> E
    F --> E
    E --> G
```

Sources: [backend/py_files/churn_service.py11-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L11-L12)[backend/py_files/churn_service.py18-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L18-L44)[backend/py_files/churn_service.py47-54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L47-L54)[backend/py_files/churn_service.py60-84](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L60-L84)

## Technical Implementation Details

### Artifact Management

The model artifact is stored using Git LFS due to its binary nature.

- **File**: `backend/models/churn_model_ada.pkl`[backend/models/churn_model_ada.pkl1-3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L3)
- **Size**: ~55 KB [backend/models/churn_model_ada.pkl3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L3-L3)

### Feature Alignment Logic

A critical component of the `churn_service.py` is the `prepare_input` function, which prevents schema mismatch errors during inference.

| Step | Function | Description |
| --- | --- | --- |
| **Loading** | `load_bundle` | Loads the `.pkl` model and reads `churn_prediction_data.csv` to reconstruct the `expected_columns` list [backend/py_files/churn_service.py18-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L18-L44) |
| **Encoding** | `prepare_input` | Applies `pd.get_dummies` to the single-row input DataFrame [backend/py_files/churn_service.py52-53](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L52-L53) |
| **Reindexing** | `prepare_input` | Uses `.reindex(columns=expected_columns, fill_value=0)` to ensure every dummy column present during training exists in the inference vector [backend/py_files/churn_service.py54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L54-L54) |

### Prediction Logic

The `predict_churn` function returns both a categorical label and a numerical probability.

**Inference Sequence**

```mermaid
sequenceDiagram
    participant API as app.py
    participant SVC as churn_service.py
    participant MDL as churn_model_ada.pkl
    API->>SVC: predict_churn(PredictRequest)
    SVC->>SVC: prepare_input(data)
    SVC->>MDL: model.predict(input_df)
    MDL-->>SVC: "Yes" / "No"
    SVC->>MDL: model.predict_proba(input_df)
    MDL-->>SVC: [prob_no, prob_yes]
    SVC-->>API: {"prediction": "Yes", "probability": 0.85}
```

Sources: [backend/py_files/churn_service.py60-84](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L60-L84)[backend/py_files/churn_service.py80-82](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L80-L82)

## Key Functions and Classes

### `PredictRequest`

A Pydantic model that validates the incoming JSON payload. It expects a `data` dictionary containing keys like `Tenure Months`, `Monthly Charges`, and `Contract`[backend/py_files/churn_service.py11-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L11-L12)

### `load_bundle()`

Executed at module startup to minimize latency. It performs a "fail-fast" check; if the `.pkl` or training `.csv` are missing, it raises a `RuntimeError`[backend/py_files/churn_service.py18-31](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L18-L31)

### `predict_churn(request: PredictRequest)`

The primary entry point for the FastAPI route. It:

1. Validates that `request.data` is not empty [backend/py_files/churn_service.py61-62](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L61-L62)
2. Preprocesses data via `prepare_input`[backend/py_files/churn_service.py64-68](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L64-L68)
3. Extracts numeric predictions and maps "Yes/No" strings to `prediction_numeric` values (1 for Yes, 0 for No) [backend/py_files/churn_service.py70-78](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L70-L78)
4. Extracts churn probability using `predict_proba` if the model supports it [backend/py_files/churn_service.py80-82](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L80-L82)

Sources: [backend/py_files/churn_service.py1-85](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/churn_service.py#L1-L85)