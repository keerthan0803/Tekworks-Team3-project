# Glossary
Relevant source files
- [README.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1)
- [backend/app.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py)
- [backend/ipynb files/churn_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/churn_prediction.ipynb)
- [backend/ipynb files/subscription_renewal_prediction.ipynb](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/ipynb files/subscription_renewal_prediction.ipynb)
- [backend/models/churn_model_ada.pkl](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl)
- [backend/processed_datasets/churn_prediction_data.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/churn_prediction_data.csv)
- [backend/processed_datasets/subscription_renewal_data.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/processed_datasets/subscription_renewal_data.csv)
- [backend/py_files/customer_segmentation_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py)
- [backend/py_files/purchase_propensity_service.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py)
- [backend/py_files/subscription.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/subscription.py)
- [backend/raw_datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/raw_datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv)
- [document.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1)
- [frontend/index.html](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/index.html)
- [frontend/src/App.css](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css)
- [frontend/src/App.tsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx)
- [frontend/src/index.css](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css)

This glossary provides technical definitions for domain-specific terms, machine learning concepts, and UI components used within the Tekworks Team3 project. It serves as a reference for understanding the implementation details and the relationship between the Natural Language Space (business logic) and the Code Entity Space (implementation).

## Core System Terms

| Term | Definition | Code Pointer |
| --- | --- | --- |
| **Inference Service** | A backend module responsible for loading ML artifacts and processing live prediction requests. | `backend/py_files/*_service.py` |
| **PredictRequest** | A Pydantic model used to validate incoming JSON payloads for model inference. | [backend/py_files/purchase_propensity_service.py11-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L11-L12) |
| **Artifact** | Serialized files (`.pkl` or `.joblib`) containing trained models, scalers, or encoders. | [backend/app.py17-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L17-L44) |
| **ViewConfig** | A frontend configuration object defining the UI structure for a specific model workspace. | [frontend/src/App.tsx1-100](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L1-L100) |
| **Workspace** | A dedicated UI area in the frontend for interacting with a specific predictive model. | [frontend/src/App.css162-168](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L162-L168) |

**Sources:**[backend/app.py17-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L17-L44)[frontend/src/App.tsx1-100](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L1-L100)[frontend/src/App.css162-168](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L162-L168)

---

## Machine Learning Concepts

### 1. Data Transformation

- **Label Encoding**: Converting categorical text labels into numerical integers. Used in `customer_segmentation_service.py` via `gender_encoder`.
- **Standard Scaling**: Normalizing numerical features to have a mean of 0 and variance of 1.
- **One-Hot Encoding**: Expanding categorical variables into multiple binary columns (e.g., `pd.get_dummies`).

### 2. Dimensionality Reduction

- **t-SNE (t-Distributed Stochastic Neighbor Embedding)**: A non-linear dimensionality reduction technique used to visualize high-dimensional customer data in 2D space.
- **Perplexity**: A hyperparameter for t-SNE that balances local and global aspects of the data.

### 3. Model Types

- **AdaBoostClassifier**: Used for Churn prediction.
- **KMeans**: Used for Customer Segmentation to group users into clusters (At-Risk, Occasional, Regular, High-Value).
- **LogisticRegression**: Used for Market Response and Purchase Propensity.

### System Mapping: Data Flow to Code Entities

The following diagram bridges the conceptual "Data Processing" space to the actual code entities that execute these tasks.

**Data Pipeline Entity Mapping**

```mermaid
flowchart LR
    subgraph subGraph1 ["Code Entity Space"]
        A1["frontend/src/App.tsx: formState"]
        B1["backend/py_files/purchase_propensity_service.py: prepare_input()"]
        C1["backend/py_files/purchase_propensity_service.py: predict_purchase_propensity()"]
        D1["frontend/src/App.tsx: prediction-output-pane"]
    end
    subgraph subGraph0 ["Natural Language Space"]
        A["User Input"]
        B["Data Preprocessing"]
        C["Model Inference"]
        D["Result Visualization"]
    end
    A --> A1
    B --> B1
    C --> C1
    D --> D1
    A1 -->|"POST Request"| C1
    C1 -->|"Calls"| B1
    B1 -->|"Returns DataFrame"| C1
    C1 -->|"JSON Response"| D1
```

**Sources:**[backend/py_files/purchase_propensity_service.py47-101](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/purchase_propensity_service.py#L47-L101)[frontend/src/App.tsx1-200](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L1-L200)

---

## UI Components & Styles

### 1. Layout Components

- **intellix-sidebar**: The primary navigation component containing links to different model views. Defined in [frontend/src/App.css11-23](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L11-L23)
- **parameters-card**: The container for input forms where users provide features for the ML models. Defined in [frontend/src/App.css242-251](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L242-L251)
- **prediction-output-pane**: The area where the backend response (prediction and probability) is rendered.

### 2. Design Tokens (CSS Variables)

The system uses a set of CSS variables defined in `:root` to maintain visual consistency.

| Variable | Usage | Code Pointer |
| --- | --- | --- |
| `--primary` | Main brand color (#0055D4) | [frontend/src/index.css3](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L3-L3) |
| `--bg-main` | Application background (#F3F6FA) | [frontend/src/index.css8](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L8-L8) |
| `--text-muted` | Secondary text for labels (#94A3B8) | [frontend/src/index.css18](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/index.css#L18-L18) |

### System Mapping: UI Component to CSS Definitions

This diagram maps the visible UI elements to their corresponding CSS classes and implementation files.

**UI Implementation Mapping**

```mermaid
flowchart TD
    subgraph subGraph1 ["Code Entity (CSS/React)"]
        C1["frontend/src/App.css: .intellix-sidebar"]
        C2["frontend/src/App.css: .parameters-body"]
        C3["frontend/src/App.tsx: Icons.Export"]
    end
    subgraph subGraph0 ["Visual UI Element"]
        UI1["Navigation Sidebar"]
        UI2["Feature Input Form"]
        UI3["Export Button"]
    end
    UI1 --> C1
    UI2 --> C2
    UI3 --> C3
```

**Sources:**[frontend/src/App.css11-23](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L11-L23)[frontend/src/App.css334-336](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.css#L334-L336)[frontend/src/App.tsx46-50](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L46-L50)

---

## Abbreviations

- **API**: Application Programming Interface (FastAPI implementation).
- **CORS**: Cross-Origin Resource Sharing (Configured in `app.py` to allow frontend communication).
- **LFS**: Git Large File Storage (Used for managing `.pkl` artifacts).
- **TSNE**: t-Distributed Stochastic Neighbor Embedding.
- **VITE**: The build tool used for the React frontend.

**Sources:**[backend/app.py9-15](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L9-L15)[backend/models/churn_model_ada.pkl1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/models/churn_model_ada.pkl#L1-L4)[backend/py_files/customer_segmentation_service.py56-66](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/py_files/customer_segmentation_service.py#L56-L66)