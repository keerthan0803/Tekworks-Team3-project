# Project Overview
Relevant source files
- [README.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1)
- [backend/app.py](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py)
- [document.md](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1)
- [frontend/src/App.tsx](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx)

The **Tekworks Team3 ML Platform** is a full-stack machine learning ecosystem designed to serve multiple predictive models through a unified interface [README.md1-4](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L1-L4) The system bridges the gap between offline model training and online real-time inference by providing a robust FastAPI backend and a modern React-based frontend [document.md4-5](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L4-L5)

## System Purpose

The platform centralizes seven distinct predictive models, ranging from customer behavior analysis (Churn, Propensity) to operational forecasting (Product Demand, Sensitivity) [README.md5-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L5-L12) It provides a standardized pipeline where raw data is processed, models are trained into serialized artifacts, and then served via RESTful endpoints [document.md22-35](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L22-L35)

### Core Predictive Services

| Model | Domain | Primary Goal |
| --- | --- | --- |
| **Churn Prediction** | Customer Retention | Identify customers at risk of leaving [backend/app.py52-54](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L52-L54) |
| **Subscription Renewal** | Subscription Mgmt | Predict likelihood of service renewal [backend/app.py57-59](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L57-L59) |
| **Market Response** | Marketing | Predict campaign engagement [backend/app.py62-64](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L62-L64) |
| **Product Demand** | Inventory | Forecast future product requirements [backend/app.py67-69](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L67-L69) |
| **Product Sensitivity** | Dynamic Pricing | Analyze price elasticity and sensitivity [backend/app.py72-76](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L72-L76) |
| **Purchase Propensity** | Sales | Score leads based on buying probability [backend/app.py79-83](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L79-L83) |
| **Customer Segmentation** | Analytics | Group customers using KMeans clustering [backend/app.py86-90](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L86-L90) |

Sources: [README.md5-12](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L5-L12)[backend/app.py52-90](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L52-L90)[document.md42-64](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L42-L64)

## High-Level Architecture

The platform follows a decoupled architecture consisting of a **FastAPI** backend and a **Vite + React** frontend. The backend acts as an inference engine, loading pre-trained `.pkl` or `.joblib` artifacts from the `backend/models/` directory [document.md84](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L84-L84)

### Logical Architecture Diagram

The following diagram illustrates how frontend components interact with backend routes and their corresponding service modules.

```mermaid
flowchart LR
    subgraph subGraph2 ["Backend (FastAPI)"]
        HUB["app.py #91;backend/app.py#93;"]
        CORS["CORSMiddleware #91;backend/app.py:9-15#93;"]
        subgraph subGraph1 ["Inference Services"]
            CS["churn_service.py"]
            SS["subscription_service.py"]
            MS["market_response_service.py"]
            DS["product_demand_service.py"]
        end
    end
    subgraph subGraph0 ["Frontend (Vite + React)"]
        UI["App.tsx #91;frontend/src/App.tsx#93;"]
        VConfig["ViewConfig #91;frontend/src/App.tsx:135#93;"]
        HSubmit["handleSubmit #91;frontend/src/App.tsx:1268#93;"]
    end
    UI -->|"Uses"| VConfig
    HSubmit -->|"POST Requests"| HUB
    HUB -->|"Invokes"| CS
    HUB -->|"Invokes"| SS
    HUB -->|"Invokes"| MS
    HUB -->|"Invokes"| DS
```

Sources: [frontend/src/App.tsx135](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L135-L135)[frontend/src/App.tsx1268](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/frontend/src/App.tsx#L1268-L1268)[backend/app.py1-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L1-L44)[document.md6-9](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L6-L9)

## ML Lifecycle & Data Flow

The project implements a two-stage lifecycle:

1. **Offline Stage**: Jupyter notebooks in `backend/ipynb files/` are used for EDA and preprocessing [document.md32-35](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L32-L35) Training scripts in `backend/py_files/` consume processed datasets to generate model artifacts [README.md36-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L36-L44)
2. **Online Stage**: The FastAPI `app.py` loads these artifacts into memory and serves them via specific routes (e.g., `/predict/churn`) [backend/app.py17-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L17-L44)

### Code-to-System Mapping

This diagram maps specific code entities to their roles in the ML lifecycle.

```mermaid
flowchart LR
    subgraph subGraph2 ["Inference Logic"]
        SERV["predict_churn #91;backend/app.py:20#93;"]
    end
    subgraph subGraph1 ["API Layer"]
        ROUTE["app.post('/predict/churn')"]
        REQ["ChurnRequest #91;backend/app.py:20#93;"]
    end
    subgraph subGraph0 ["Data & Training"]
        RAW["backend/raw_datasets/"]
        TRAIN["backend/py_files/churn.py"]
        ART["backend/models/*.pkl"]
    end
    RAW -->|"Input to"| TRAIN
    TRAIN -->|"Generates"| ART
    ART -->|"Loaded by"| SERV
    ROUTE -->|"Uses"| REQ
    REQ -->|"Passed to"| SERV
```

Sources: [backend/app.py20-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/backend/app.py#L20-L44)[README.md36-44](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L36-L44)[document.md32-35](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L32-L35)

## Detailed Documentation

For specific implementation details, refer to the following child pages:

- **[Getting Started](/Kranthikumar06/Tekworks-Team3-project/1.1-getting-started)**: Step-by-step instructions for environment setup, dependency installation (Python/Node), and running the development servers [README.md14-28](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L14-L28)
- **[Repository Layout](/Kranthikumar06/Tekworks-Team3-project/1.2-repository-layout)**: A deep dive into the directory structure, explaining the purpose of `backend/`, `frontend/`, and the various asset folders [document.md6-9](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L6-L9)

Sources: [README.md14-34](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/README.md?plain=1#L14-L34)[document.md6-35](https://github.com/Kranthikumar06/Tekworks-Team3-project/blob/c4d76b47/document.md?plain=1#L6-L35)